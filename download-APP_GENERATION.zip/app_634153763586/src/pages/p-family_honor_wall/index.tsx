

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface Achievement {
  id: string;
  type: 'badge' | 'work';
  child: string;
  time: string;
  likes: number;
  title: string;
  description: string;
  icon?: string;
  imageUrl?: string;
  isLiked: boolean;
}

const FamilyHonorWall: React.FC = () => {
  const [selectedChild, setSelectedChild] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [sortBy, setSortBy] = useState('latest');
  const [searchTerm, setSearchTerm] = useState('');
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);

  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: 'badge-1',
      type: 'badge',
      child: 'xiaoming',
      time: '2024-01-15',
      likes: 12,
      title: '坚持不懈奖',
      description: '连续7天完成任务',
      icon: 'fas fa-trophy',
      isLiked: false
    },
    {
      id: 'work-1',
      type: 'work',
      child: 'xiaoming',
      time: '2024-01-14',
      likes: 8,
      title: '数学小达人',
      description: '完成数学练习册第3章，正确率95%',
      imageUrl: 'https://s.coze.cn/image/20yuGc2z0_M/',
      isLiked: false
    },
    {
      id: 'badge-2',
      type: 'badge',
      child: 'xiaoming',
      time: '2024-01-13',
      likes: 15,
      title: '探索家奖',
      description: '首次尝试新领域的任务',
      icon: 'fas fa-rocket',
      isLiked: false
    },
    {
      id: 'work-2',
      type: 'work',
      child: 'xiaoming',
      time: '2024-01-12',
      likes: 6,
      title: '小小画家',
      description: '完成了一幅美丽的风景画',
      imageUrl: 'https://s.coze.cn/image/VP4JnVnqJEY/',
      isLiked: false
    },
    {
      id: 'badge-3',
      type: 'badge',
      child: 'xiaoming',
      time: '2024-01-11',
      likes: 9,
      title: '创意大师奖',
      description: '用有趣方式完成任务',
      icon: 'fas fa-lightbulb',
      isLiked: false
    },
    {
      id: 'work-3',
      type: 'work',
      child: 'xiaoming',
      time: '2024-01-10',
      likes: 11,
      title: '巧手小工匠',
      description: '制作了一个精美的纸飞机模型',
      imageUrl: 'https://s.coze.cn/image/Piu_sEQMSWY/',
      isLiked: false
    },
    {
      id: 'badge-4',
      type: 'badge',
      child: 'xiaoming',
      time: '2024-01-09',
      likes: 7,
      title: '阅读小达人',
      description: '一周内完成5本书的阅读',
      icon: 'fas fa-book',
      isLiked: false
    },
    {
      id: 'work-4',
      type: 'work',
      child: 'xiaoming',
      time: '2024-01-08',
      likes: 13,
      title: '小小科学家',
      description: '成功完成了水的浮力实验',
      imageUrl: 'https://s.coze.cn/image/I_lNLia60c8/',
      isLiked: false
    }
  ]);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '家庭荣誉墙 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  const filteredAndSortedAchievements = React.useMemo(() => {
    let filtered = achievements.filter(achievement => {
      const matchesChild = selectedChild === 'all' || achievement.child === selectedChild;
      const matchesType = selectedType === 'all' || achievement.type === selectedType;
      const matchesSearch = !searchTerm || 
        achievement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        achievement.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesChild && matchesType && matchesSearch;
    });

    filtered.sort((a, b) => {
      if (sortBy === 'earliest') {
        return new Date(a.time).getTime() - new Date(b.time).getTime();
      } else if (sortBy === 'most-liked') {
        return b.likes - a.likes;
      } else {
        return new Date(b.time).getTime() - new Date(a.time).getTime();
      }
    });

    return filtered;
  }, [achievements, selectedChild, selectedType, sortBy, searchTerm]);

  const handleLikeToggle = (achievementId: string) => {
    setAchievements(prev => prev.map(achievement => {
      if (achievement.id === achievementId) {
        return {
          ...achievement,
          isLiked: !achievement.isLiked,
          likes: achievement.isLiked ? achievement.likes - 1 : achievement.likes + 1
        };
      }
      return achievement;
    }));
  };

  const handleAchievementClick = (achievement: Achievement) => {
    setSelectedAchievement(achievement);
    setIsDetailModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsDetailModalOpen(false);
    setSelectedAchievement(null);
  };

  const handleModalBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  const handleEscapeKey = (e: KeyboardEvent) => {
    if (e.key === 'Escape' && isDetailModalOpen) {
      handleCloseModal();
    }
  };

  useEffect(() => {
    document.addEventListener('keydown', handleEscapeKey);
    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isDetailModalOpen]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const getIconColor = (icon: string) => {
    if (icon.includes('trophy')) return 'text-yellow-600';
    if (icon.includes('rocket')) return 'text-blue-600';
    if (icon.includes('lightbulb')) return 'text-green-600';
    if (icon.includes('book')) return 'text-purple-600';
    return 'text-gray-600';
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/BNNZRKKFrt4/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/vJoXjQYhMO0/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover"
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link to="/parent-dashboard" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link to="/task-list" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link to="/wish-list" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link to="/family-honor-wall" className={`${styles.sidebarItem} ${styles.active} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}>
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link to="/growth-report" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link to="/knowledge-base" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link to="/family-manage" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link to="/user-profile" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link to="/settings" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">家庭荣誉墙</h2>
                <nav className="text-sm text-text-secondary">
                  <span>家庭荣誉墙</span>
                </nav>
              </div>
            </div>
          </div>

          {/* 筛选和排序工具栏 */}
          <div className="bg-white rounded-2xl shadow-card p-4 mb-6">
            <div className="flex flex-wrap items-center gap-4">
              {/* 孩子筛选 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">孩子：</label>
                <select 
                  value={selectedChild}
                  onChange={(e) => setSelectedChild(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="all">全部孩子</option>
                  <option value="xiaoming">小明</option>
                  <option value="xiaohong">小红</option>
                </select>
              </div>

              {/* 类型筛选 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">类型：</label>
                <select 
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="all">全部类型</option>
                  <option value="badge">徽章</option>
                  <option value="work">作品</option>
                </select>
              </div>

              {/* 时间排序 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">排序：</label>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="latest">最新获得</option>
                  <option value="earliest">最早获得</option>
                  <option value="most-liked">最多点赞</option>
                </select>
              </div>

              {/* 搜索框 */}
              <div className="flex-1 max-w-xs">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="搜索成就..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                </div>
              </div>
            </div>
          </div>

          {/* 成就展示区域 */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAndSortedAchievements.map((achievement) => (
              <div 
                key={achievement.id}
                className={`${styles.achievementCard} bg-white rounded-2xl shadow-card overflow-hidden cursor-pointer`}
                onClick={() => handleAchievementClick(achievement)}
              >
                {achievement.type === 'badge' ? (
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`${styles.badgeIcon} w-16 h-16 rounded-full flex items-center justify-center`}>
                        <i className={`${achievement.icon} text-2xl ${getIconColor(achievement.icon!)}`}></i>
                      </div>
                      <button 
                        className={`${styles.likeButton} ${achievement.isLiked ? 'text-danger' : 'text-gray-400 hover:text-danger'}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleLikeToggle(achievement.id);
                        }}
                      >
                        <i className="fas fa-heart text-lg"></i>
                      </button>
                    </div>
                    <h3 className="text-lg font-semibold text-text-primary mb-2">{achievement.title}</h3>
                    <p className="text-sm text-text-secondary mb-3">{achievement.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-text-secondary">{formatDate(achievement.time)}</span>
                      <span className="text-xs text-danger font-medium">{achievement.likes}</span>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="relative">
                      <img 
                        src={achievement.imageUrl} 
                        alt={achievement.title} 
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-3 right-3">
                        <button 
                          className={`${styles.likeButton} bg-white bg-opacity-80 rounded-full p-2 ${achievement.isLiked ? 'text-danger' : 'text-gray-400 hover:text-danger'}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLikeToggle(achievement.id);
                          }}
                        >
                          <i className="fas fa-heart"></i>
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-text-primary mb-2">{achievement.title}</h3>
                      <p className="text-sm text-text-secondary mb-3">{achievement.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-text-secondary">{formatDate(achievement.time)}</span>
                        <span className="text-xs text-danger font-medium">{achievement.likes}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </section>

          {/* 空状态提示 */}
          {filteredAndSortedAchievements.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-trophy text-3xl text-gray-400"></i>
              </div>
              <h3 className="text-lg font-semibold text-text-primary mb-2">暂无相关成就</h3>
              <p className="text-text-secondary">当前筛选条件下没有找到相关成就</p>
            </div>
          )}
        </main>
      </div>

      {/* 详情模态弹窗 */}
      {isDetailModalOpen && selectedAchievement && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
          onClick={handleModalBackdropClick}
        >
          <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-text-primary">{selectedAchievement.title}</h3>
                <button 
                  className="text-gray-400 hover:text-gray-600"
                  onClick={handleCloseModal}
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              <div className="space-y-4">
                {selectedAchievement.type === 'badge' ? (
                  <>
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-full flex items-center justify-center">
                        <i className={`${selectedAchievement.icon} text-2xl ${getIconColor(selectedAchievement.icon!)}`}></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-text-primary">徽章成就</h4>
                        <p className="text-sm text-text-secondary">获得时间：{formatDate(selectedAchievement.time)}</p>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h5 className="font-medium text-text-primary mb-2">获得条件</h5>
                      <p className="text-sm text-text-secondary">{selectedAchievement.description}</p>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <span className="text-sm text-text-secondary">
                        <i className="fas fa-heart text-danger mr-1"></i>获得 {selectedAchievement.likes} 个点赞
                      </span>
                      <button className="text-primary text-sm hover:underline">查看相关任务</button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="mb-4">
                      <img 
                        src={selectedAchievement.imageUrl} 
                        alt={selectedAchievement.title} 
                        className="w-full h-64 object-cover rounded-lg"
                      />
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      <h5 className="font-medium text-text-primary mb-2">作品描述</h5>
                      <p className="text-sm text-text-secondary">{selectedAchievement.description}</p>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <span className="text-sm text-text-secondary">
                        完成时间：{formatDate(selectedAchievement.time)}
                      </span>
                      <span className="text-sm text-text-secondary">
                        <i className="fas fa-heart text-danger mr-1"></i>获得 {selectedAchievement.likes} 个点赞
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FamilyHonorWall;

