

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface FamilyMember {
  id: string;
  name: string;
  role: 'parent' | 'child';
  avatar: string;
  joinDate: string;
  isCreator?: boolean;
}

interface InviteFormData {
  name: string;
  role: 'parent' | 'child';
  email: string;
}

interface EditFormData {
  name: string;
  role: 'parent' | 'child';
}

const FamilyManagePage: React.FC = () => {
  const navigate = useNavigate();
  
  // 模态框状态
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  
  // 表单数据
  const [inviteFormData, setInviteFormData] = useState<InviteFormData>({
    name: '',
    role: 'parent',
    email: ''
  });
  
  const [editFormData, setEditFormData] = useState<EditFormData>({
    name: '',
    role: 'parent'
  });
  
  const [currentEditMemberId, setCurrentEditMemberId] = useState<string | null>(null);
  const [currentRemoveMember, setCurrentRemoveMember] = useState<FamilyMember | null>(null);
  
  // 家庭成员数据
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    {
      id: 'member1',
      name: '李爸爸',
      role: 'parent',
      avatar: 'https://s.coze.cn/image/R7Mxp378zzc/',
      joinDate: '2024-01-15',
      isCreator: true
    },
    {
      id: 'member2',
      name: '王妈妈',
      role: 'parent',
      avatar: 'https://s.coze.cn/image/xs4jTwb3PFw/',
      joinDate: '2024-01-16'
    },
    {
      id: 'member3',
      name: '小明',
      role: 'child',
      avatar: 'https://s.coze.cn/image/GRU533ZbpHw/',
      joinDate: '2024-01-16'
    },
    {
      id: 'member4',
      name: '小红',
      role: 'child',
      avatar: 'https://s.coze.cn/image/gXG1Gb8dbQQ/',
      joinDate: '2024-01-20'
    }
  ]);
  
  // 权限设置状态
  const [parentPermissions, setParentPermissions] = useState({
    taskSuggest: true,
    taskConfirm: true,
    wishReview: true,
    viewReport: true
  });
  
  const [childPermissions, setChildPermissions] = useState({
    createTask: true,
    createWish: true,
    viewHonor: true,
    viewEnergy: true
  });
  
  // 全局搜索
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '家庭管理 - 星火计划';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 处理侧边栏点击
  const handleSidebarItemClick = (e: React.MouseEvent, href: string) => {
    if (href === '#') {
      e.preventDefault();
    }
  };

  // 处理邀请成员
  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // 模拟发送邀请
    alert('邀请已发送！');
    setShowInviteModal(false);
    setInviteFormData({ name: '', role: 'parent', email: '' });
  };

  // 处理编辑成员
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentEditMemberId) {
      setFamilyMembers(prev => prev.map(member => 
        member.id === currentEditMemberId 
          ? { ...member, name: editFormData.name, role: editFormData.role }
          : member
      ));
      alert('成员信息已更新！');
      setShowEditModal(false);
      setCurrentEditMemberId(null);
    }
  };

  // 处理移除成员
  const handleRemoveConfirm = () => {
    if (currentRemoveMember) {
      setFamilyMembers(prev => prev.filter(member => member.id !== currentRemoveMember.id));
      alert('成员已移除！');
      setShowRemoveModal(false);
      setCurrentRemoveMember(null);
    }
  };

  // 处理保存权限设置
  const handleSavePermissions = () => {
    alert('权限设置已保存！');
  };

  // 处理全局搜索
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索：', globalSearchValue);
    }
  };

  // 模态框背景点击处理
  const handleModalBackdropClick = (e: React.MouseEvent, closeModal: () => void) => {
    if (e.target === e.currentTarget) {
      closeModal();
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/R5_wbDvFXLA/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full" 
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/EW1UxorT9p0/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover" 
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/parent-dashboard')}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/task-list')}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/wish-list')}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/family-honor-wall')}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/growth-report')}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/knowledge-base')}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <a 
                  href="#" 
                  className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '#')}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </a>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/user-profile')}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                  onClick={(e) => handleSidebarItemClick(e, '/settings')}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">家庭管理</h2>
                <nav className="text-sm text-text-secondary">
                  <span>家庭管理</span>
                </nav>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={() => setShowInviteModal(true)}
                  className={`${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-user-plus mr-2"></i>邀请成员
                </button>
              </div>
            </div>
          </div>

          {/* 家庭成员列表 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">家庭成员</h3>
                <span className="text-sm text-text-secondary">共{familyMembers.length}位成员</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">头像</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">昵称</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">角色</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">加入时间</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {familyMembers.map((member) => (
                      <tr key={member.id} className={`${styles.tableRow} ${familyMembers.indexOf(member) < familyMembers.length - 1 ? 'border-b border-gray-100' : ''}`}>
                        <td className="py-3 px-4">
                          <img 
                            src={member.avatar} 
                            alt={`${member.name}头像`} 
                            className="w-12 h-12 rounded-full" 
                          />
                        </td>
                        <td className="py-3 px-4 font-medium text-text-primary">{member.name}</td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            member.role === 'parent' 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            <i className={`fas ${member.role === 'parent' ? 'fa-user-tie' : 'fa-child'} mr-1`}></i>
                            {member.role === 'parent' ? '家长' : '孩子'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm text-text-secondary">{member.joinDate}</td>
                        <td className="py-3 px-4">
                          {member.isCreator ? (
                            <span className="text-sm text-text-secondary">创建者</span>
                          ) : (
                            <div className="flex space-x-2">
                              <button 
                                onClick={() => {
                                  setCurrentEditMemberId(member.id);
                                  setEditFormData({ name: member.name, role: member.role });
                                  setShowEditModal(true);
                                }}
                                className="text-primary text-sm hover:underline"
                              >
                                编辑
                              </button>
                              {!member.isCreator && member.id !== 'member2' && (
                                <button 
                                  onClick={() => {
                                    setCurrentRemoveMember(member);
                                    setShowRemoveModal(true);
                                  }}
                                  className="text-danger text-sm hover:underline"
                                >
                                  移除
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* 权限设置区 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">权限设置</h3>
                <button 
                  onClick={handleSavePermissions}
                  className={`${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-save mr-2"></i>保存设置
                </button>
              </div>
              
              {/* 家长权限 */}
              <div className="mb-8">
                <h4 className="text-md font-medium text-text-primary mb-4 flex items-center">
                  <i className="fas fa-user-tie text-blue-500 mr-2"></i>家长权限
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">任务建议权限</p>
                      <p className="text-sm text-text-secondary">向孩子发布任务建议</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={parentPermissions.taskSuggest}
                        onChange={(e) => setParentPermissions(prev => ({ ...prev, taskSuggest: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">任务确认权限</p>
                      <p className="text-sm text-text-secondary">确认孩子创建的任务</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={parentPermissions.taskConfirm}
                        onChange={(e) => setParentPermissions(prev => ({ ...prev, taskConfirm: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">心愿审核权限</p>
                      <p className="text-sm text-text-secondary">审核孩子的心愿申请</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={parentPermissions.wishReview}
                        onChange={(e) => setParentPermissions(prev => ({ ...prev, wishReview: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">查看成长报告</p>
                      <p className="text-sm text-text-secondary">查看孩子的详细成长报告</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={parentPermissions.viewReport}
                        onChange={(e) => setParentPermissions(prev => ({ ...prev, viewReport: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                </div>
              </div>
              
              {/* 孩子权限 */}
              <div>
                <h4 className="text-md font-medium text-text-primary mb-4 flex items-center">
                  <i className="fas fa-child text-green-500 mr-2"></i>孩子权限
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">创建任务权限</p>
                      <p className="text-sm text-text-secondary">自主创建和管理个人任务</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={childPermissions.createTask}
                        onChange={(e) => setChildPermissions(prev => ({ ...prev, createTask: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">创建心愿权限</p>
                      <p className="text-sm text-text-secondary">创建和管理个人心愿清单</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={childPermissions.createWish}
                        onChange={(e) => setChildPermissions(prev => ({ ...prev, createWish: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">查看荣誉墙</p>
                      <p className="text-sm text-text-secondary">查看家庭荣誉墙和个人成就</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={childPermissions.viewHonor}
                        onChange={(e) => setChildPermissions(prev => ({ ...prev, viewHonor: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-text-primary">查看能量值</p>
                      <p className="text-sm text-text-secondary">查看个人能量值和徽章</p>
                    </div>
                    <label className={styles.switch}>
                      <input 
                        type="checkbox" 
                        checked={childPermissions.viewEnergy}
                        onChange={(e) => setChildPermissions(prev => ({ ...prev, viewEnergy: e.target.checked }))}
                      />
                      <span className={styles.slider}></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 邀请成员弹窗 */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={(e) => handleModalBackdropClick(e, () => setShowInviteModal(false))}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`bg-white rounded-2xl shadow-gradient p-6 w-full max-w-md ${styles.modalEnter}`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">邀请家庭成员</h3>
                <button 
                  onClick={() => setShowInviteModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              <form onSubmit={handleInviteSubmit} className="space-y-4">
                <div>
                  <label htmlFor="invite-name" className="block text-sm font-medium text-text-primary mb-2">成员昵称</label>
                  <input 
                    type="text" 
                    id="invite-name" 
                    name="name" 
                    value={inviteFormData.name}
                    onChange={(e) => setInviteFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    placeholder="请输入成员昵称"
                  />
                </div>
                <div>
                  <label htmlFor="invite-role" className="block text-sm font-medium text-text-primary mb-2">角色</label>
                  <select 
                    id="invite-role" 
                    name="role" 
                    value={inviteFormData.role}
                    onChange={(e) => setInviteFormData(prev => ({ ...prev, role: e.target.value as 'parent' | 'child' }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="parent">家长</option>
                    <option value="child">孩子</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="invite-email" className="block text-sm font-medium text-text-primary mb-2">邮箱</label>
                  <input 
                    type="email" 
                    id="invite-email" 
                    name="email" 
                    value={inviteFormData.email}
                    onChange={(e) => setInviteFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    placeholder="请输入邮箱地址"
                  />
                </div>
                <div className="flex space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => setShowInviteModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:border-primary transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg font-medium`}
                  >
                    发送邀请
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 编辑成员弹窗 */}
      {showEditModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={(e) => handleModalBackdropClick(e, () => setShowEditModal(false))}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`bg-white rounded-2xl shadow-gradient p-6 w-full max-w-md ${styles.modalEnter}`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">编辑成员信息</h3>
                <button 
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              <form onSubmit={handleEditSubmit} className="space-y-4">
                <div>
                  <label htmlFor="edit-name" className="block text-sm font-medium text-text-primary mb-2">成员昵称</label>
                  <input 
                    type="text" 
                    id="edit-name" 
                    name="name" 
                    value={editFormData.name}
                    onChange={(e) => setEditFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                    placeholder="请输入成员昵称"
                  />
                </div>
                <div>
                  <label htmlFor="edit-role" className="block text-sm font-medium text-text-primary mb-2">角色</label>
                  <select 
                    id="edit-role" 
                    name="role" 
                    value={editFormData.role}
                    onChange={(e) => setEditFormData(prev => ({ ...prev, role: e.target.value as 'parent' | 'child' }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="parent">家长</option>
                    <option value="child">孩子</option>
                  </select>
                </div>
                <div className="flex space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:border-primary transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg font-medium`}
                  >
                    保存
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 移除成员确认弹窗 */}
      {showRemoveModal && currentRemoveMember && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={(e) => handleModalBackdropClick(e, () => {
            setShowRemoveModal(false);
            setCurrentRemoveMember(null);
          })}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`bg-white rounded-2xl shadow-gradient p-6 w-full max-w-md ${styles.modalEnter}`}>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">确认移除成员</h3>
                <p className="text-text-secondary mb-6">
                  确定要移除 <span className="font-medium text-text-primary">{currentRemoveMember.name}</span> 吗？此操作不可撤销。
                </p>
                <div className="flex space-x-3">
                  <button 
                    onClick={() => {
                      setShowRemoveModal(false);
                      setCurrentRemoveMember(null);
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:border-primary transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleRemoveConfirm}
                    className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-600 transition-colors"
                  >
                    确认移除
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FamilyManagePage;

