

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const GrowthReportPage: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'weekly' | 'monthly'>('weekly');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '成长报告 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  const handleTabChange = (tab: 'weekly' | 'monthly') => {
    setActiveTab(tab);
  };

  const handleDownloadReport = () => {
    console.log('需要调用第三方接口实现报告下载功能');
    alert('报告下载功能正在开发中...');
  };

  const handleShareReport = () => {
    console.log('需要调用第三方接口实现报告分享功能');
    alert('报告分享功能正在开发中...');
  };

  const handleNotificationClick = () => {
    console.log('显示通知列表');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button 
              onClick={handleNotificationClick}
              className="relative p-2 text-gray-600 hover:text-primary transition-colors"
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/xcK9dXeRqag/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full" 
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/flIiCv3nGH8/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover" 
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-manage" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">成长报告</h2>
                <nav className="text-sm text-text-secondary">
                  <span>成长报告</span>
                </nav>
              </div>
              <div className="flex space-x-3">
                {/* 报告周期选择器 */}
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleTabChange('weekly')}
                    className={`px-4 py-2 text-sm font-medium rounded-lg focus:outline-none ${
                      activeTab === 'weekly' ? styles.tabActive : styles.tabInactive
                    }`}
                    role="tab"
                  >
                    周报告
                  </button>
                  <button 
                    onClick={() => handleTabChange('monthly')}
                    className={`px-4 py-2 text-sm font-medium rounded-lg focus:outline-none ${
                      activeTab === 'monthly' ? styles.tabActive : styles.tabInactive
                    }`}
                    role="tab"
                  >
                    月报告
                  </button>
                </div>
                <button 
                  onClick={handleDownloadReport}
                  className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-download mr-2"></i>下载报告
                </button>
                <button 
                  onClick={handleShareReport}
                  className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-share mr-2"></i>分享报告
                </button>
              </div>
            </div>
          </div>

          {/* 报告内容区 */}
          <div>
            {/* 周报告内容 */}
            {activeTab === 'weekly' && (
              <div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  {/* 本周概览 */}
                  <div className="bg-white rounded-2xl shadow-card p-6">
                    <h3 className="text-lg font-semibold text-text-primary mb-4">本周概览</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="relative w-20 h-20 mx-auto mb-2">
                          <svg className={`${styles.progressRing} w-20 h-20`} viewBox="0 0 36 36">
                            <path 
                              className={`${styles.progressRingCircle}`} 
                              stroke="#e5e7eb" 
                              strokeWidth="3" 
                              fill="transparent" 
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            />
                            <path 
                              className={`${styles.progressRingCircle}`} 
                              stroke="#6366f1" 
                              strokeWidth="3" 
                              fill="transparent" 
                              strokeDasharray="85, 100" 
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            />
                          </svg>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-lg font-bold text-text-primary">85%</span>
                          </div>
                        </div>
                        <p className="text-sm text-text-secondary">任务完成率</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary mb-1">12</div>
                        <p className="text-sm text-text-secondary">完成任务数</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-secondary mb-1">+80</div>
                        <p className="text-sm text-text-secondary">能量值增长</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-tertiary mb-1">3</div>
                        <p className="text-sm text-text-secondary">获得徽章数</p>
                      </div>
                    </div>
                  </div>

                  {/* 能量值趋势 */}
                  <div className="bg-white rounded-2xl shadow-card p-6">
                    <h3 className="text-lg font-semibold text-text-primary mb-4">能量值趋势</h3>
                    <div className={styles.chartContainer}>
                      <div className="text-center">
                        <i className="fas fa-chart-line text-4xl text-primary mb-2"></i>
                        <p className="text-sm text-text-secondary">本周能量值稳步增长</p>
                        <p className="text-lg font-semibold text-text-primary mt-1">+80 能量值</p>
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">周一</span>
                        <span className="text-text-primary">+15</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">周二</span>
                        <span className="text-text-primary">+20</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">周三</span>
                        <span className="text-text-primary">+10</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">周四</span>
                        <span className="text-text-primary">+15</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">周五</span>
                        <span className="text-text-primary">+20</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 任务分类分析 */}
                <div className="bg-white rounded-2xl shadow-card p-6 mb-8">
                  <h3 className="text-lg font-semibold text-text-primary mb-4">任务分类分析</h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-book text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">5</div>
                      <div className="text-sm text-text-secondary">学习探索</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-heart text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">3</div>
                      <div className="text-sm text-text-secondary">习惯养成</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-palette text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">2</div>
                      <div className="text-sm text-text-secondary">兴趣技能</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-home text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">2</div>
                      <div className="text-sm text-text-secondary">家庭贡献</div>
                    </div>
                  </div>
                </div>

                {/* 家长反馈统计 */}
                <div className="bg-white rounded-2xl shadow-card p-6 mb-8">
                  <h3 className="text-lg font-semibold text-text-primary mb-4">家长反馈统计</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">5</div>
                      <div className="text-sm text-text-secondary">本周反馈次数</div>
                      <div className="mt-2">
                        <div className="flex justify-center space-x-2">
                          <i className="fas fa-heart text-red-400"></i>
                          <i className="fas fa-thumbs-up text-green-400"></i>
                          <i className="fas fa-star text-yellow-400"></i>
                          <i className="fas fa-smile text-blue-400"></i>
                          <i className="fas fa-fire text-orange-400"></i>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary mb-3">最新反馈</h4>
                      <div className="space-y-3">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-text-primary">"小明在数学练习中表现很棒，解题思路很清晰！"</p>
                          <p className="text-xs text-text-secondary mt-1">2小时前</p>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-text-primary">"坚持阅读30分钟，养成好习惯！"</p>
                          <p className="text-xs text-text-secondary mt-1">昨天</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 亮点表现 */}
                <div className="bg-white rounded-2xl shadow-card p-6">
                  <h3 className="text-lg font-semibold text-text-primary mb-4">本周亮点</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg border border-yellow-100">
                      <div className="flex items-center space-x-3 mb-2">
                        <i className="fas fa-trophy text-yellow-500"></i>
                        <span className="font-medium text-text-primary">坚持不懈奖</span>
                      </div>
                      <p className="text-sm text-text-secondary">连续7天完成任务</p>
                    </div>
                    <div className="p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg border border-blue-100">
                      <div className="flex items-center space-x-3 mb-2">
                        <i className="fas fa-lightbulb text-blue-500"></i>
                        <span className="font-medium text-text-primary">探索家奖</span>
                      </div>
                      <p className="text-sm text-text-secondary">首次尝试编程任务</p>
                    </div>
                    <div className="p-4 bg-gradient-to-br from-green-50 to-teal-50 rounded-lg border border-green-100">
                      <div className="flex items-center space-x-3 mb-2">
                        <i className="fas fa-crown text-green-500"></i>
                        <span className="font-medium text-text-primary">全能小达人</span>
                      </div>
                      <p className="text-sm text-text-secondary">完成所有分类任务</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 月报告内容 */}
            {activeTab === 'monthly' && (
              <div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  {/* 本月概览 */}
                  <div className="bg-white rounded-2xl shadow-card p-6">
                    <h3 className="text-lg font-semibold text-text-primary mb-4">本月概览</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="relative w-20 h-20 mx-auto mb-2">
                          <svg className={`${styles.progressRing} w-20 h-20`} viewBox="0 0 36 36">
                            <path 
                              className={`${styles.progressRingCircle}`} 
                              stroke="#e5e7eb" 
                              strokeWidth="3" 
                              fill="transparent" 
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            />
                            <path 
                              className={`${styles.progressRingCircle}`} 
                              stroke="#6366f1" 
                              strokeWidth="3" 
                              fill="transparent" 
                              strokeDasharray="92, 100" 
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            />
                          </svg>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-lg font-bold text-text-primary">92%</span>
                          </div>
                        </div>
                        <p className="text-sm text-text-secondary">任务完成率</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-text-primary mb-1">45</div>
                        <p className="text-sm text-text-secondary">完成任务数</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-secondary mb-1">+320</div>
                        <p className="text-sm text-text-secondary">能量值增长</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-tertiary mb-1">8</div>
                        <p className="text-sm text-text-secondary">获得徽章数</p>
                      </div>
                    </div>
                  </div>

                  {/* 月度能量趋势 */}
                  <div className="bg-white rounded-2xl shadow-card p-6">
                    <h3 className="text-lg font-semibold text-text-primary mb-4">月度能量趋势</h3>
                    <div className={styles.chartContainer}>
                      <div className="text-center">
                        <i className="fas fa-chart-area text-4xl text-primary mb-2"></i>
                        <p className="text-sm text-text-secondary">本月能量值显著提升</p>
                        <p className="text-lg font-semibold text-text-primary mt-1">+320 能量值</p>
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">第1周</span>
                        <span className="text-text-primary">+75</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">第2周</span>
                        <span className="text-text-primary">+85</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">第3周</span>
                        <span className="text-text-primary">+80</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-text-secondary">第4周</span>
                        <span className="text-text-primary">+80</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 月度分类分析 */}
                <div className="bg-white rounded-2xl shadow-card p-6 mb-8">
                  <h3 className="text-lg font-semibold text-text-primary mb-4">月度分类分析</h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-book text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">18</div>
                      <div className="text-sm text-text-secondary">学习探索</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-heart text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">12</div>
                      <div className="text-sm text-text-secondary">习惯养成</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-palette text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">8</div>
                      <div className="text-sm text-text-secondary">兴趣技能</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <i className="fas fa-home text-white"></i>
                      </div>
                      <div className="text-xl font-bold text-text-primary">7</div>
                      <div className="text-sm text-text-secondary">家庭贡献</div>
                    </div>
                  </div>
                </div>

                {/* 月度里程碑 */}
                <div className="bg-white rounded-2xl shadow-card p-6">
                  <h3 className="text-lg font-semibold text-text-primary mb-4">本月里程碑</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg">
                      <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                        <i className="fas fa-medal text-white"></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-text-primary">连续打卡王</h4>
                        <p className="text-sm text-text-secondary">连续25天完成任务，创造新纪录！</p>
                      </div>
                      <span className="text-sm text-text-secondary">15天前</span>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                        <i className="fas fa-rocket text-white"></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-text-primary">能量突破</h4>
                        <p className="text-sm text-text-secondary">能量值突破1000大关！</p>
                      </div>
                      <span className="text-sm text-text-secondary">10天前</span>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-lg">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                        <i className="fas fa-star text-white"></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-text-primary">全才小明星</h4>
                        <p className="text-sm text-text-secondary">获得所有类型的徽章各一个！</p>
                      </div>
                      <span className="text-sm text-text-secondary">5天前</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default GrowthReportPage;

