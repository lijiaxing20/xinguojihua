

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface Article {
  id: string;
  title: string;
  author: string;
  date: string;
  category: string;
  categoryColor: string;
  summary: string;
  views: string;
  likes: string;
  comments: string;
  imageUrl: string;
  content: string;
}

const KnowledgeBasePage: React.FC = () => {
  const [articleSearchTerm, setArticleSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('publish_time');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [showArticleModal, setShowArticleModal] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '知识库 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  // 模拟文章数据
  const articlesData: Article[] = [
    {
      id: 'article1',
      title: '如何培养孩子的成长型思维：从错误中学习的艺术',
      author: '张教授',
      date: '2024-01-15',
      category: '成长型思维',
      categoryColor: 'bg-blue-100 text-blue-800',
      summary: '成长型思维是孩子未来成功的关键能力。本文将分享如何通过日常对话和互动，帮助孩子建立"能力可以通过努力提升"的信念，让他们不再害怕失败，而是将错误视为学习的机会...',
      views: '1,234',
      likes: '89',
      comments: '12',
      imageUrl: 'https://s.coze.cn/image/TXSgY27J7TE/',
      content: `
        <div class="prose max-w-none">
          <h4 class="text-lg font-semibold mb-4">什么是成长型思维？</h4>
          <p class="mb-4">成长型思维是斯坦福大学心理学家卡罗尔·德韦克提出的概念，指的是相信能力可以通过努力和学习得到提升的思维模式。拥有成长型思维的孩子不会因为一时的失败而气馁，而是会将挑战视为成长的机会。</p>
          
          <h4 class="text-lg font-semibold mb-4">日常对话中的成长型思维培养</h4>
          <p class="mb-4">在与孩子的日常交流中，我们可以通过以下方式培养他们的成长型思维：</p>
          <ul class="list-disc list-inside mb-4 space-y-2">
            <li>用"你很努力"代替"你很聪明"</li>
            <li>关注过程而非结果："我看到你为这个项目付出了很多时间"</li>
            <li>将错误正常化："犯错是学习的一部分"</li>
            <li>鼓励尝试："这个挑战看起来很难，正是我们学习的好机会"</li>
          </ul>
          
          <h4 class="text-lg font-semibold mb-4">实践案例</h4>
          <p class="mb-4">当孩子考试成绩不理想时，避免说"你不够聪明"，而是说"这次考试让我们知道了哪些地方需要更多的练习"。这种对话方式帮助孩子将注意力从能力的固定观念转向可提升的技能。</p>
          
          <div class="bg-blue-50 border-l-4 border-blue-500 p-4 my-6">
            <h5 class="font-semibold text-blue-800 mb-2">💡 专家建议</h5>
            <p class="text-blue-700">每天至少对孩子说一次具体的努力肯定，例如："我注意到你今天在解决这个问题时尝试了好几种方法，这种坚持的态度很棒！"</p>
          </div>
        </div>
      `
    },
    {
      id: 'article2',
      title: '激发孩子的好奇心：让学习变得像探险一样有趣',
      author: '李老师',
      date: '2024-01-12',
      category: '好奇心培养',
      categoryColor: 'bg-green-100 text-green-800',
      summary: '好奇心是学习的原始动力。了解如何通过提问技巧、探索活动和环境创设，激发孩子对世界的好奇心，让他们主动寻求知识，享受发现的乐趣...',
      views: '956',
      likes: '67',
      comments: '8',
      imageUrl: 'https://s.coze.cn/image/sWllgs5HZM0/',
      content: `
        <div class="prose max-w-none">
          <h4 class="text-lg font-semibold mb-4">好奇心是学习的驱动力</h4>
          <p class="mb-4">好奇心是人类最原始的学习动力。当孩子对某个事物产生好奇时，他们会主动寻求答案，这种内在的驱动力比任何外部奖励都更加持久和有效。</p>
          
          <h4 class="text-lg font-semibold mb-4">提问的艺术</h4>
          <p class="mb-4">学会提问是激发好奇心的关键。家长可以通过以下方式培养孩子的提问能力：</p>
          <ul class="list-disc list-inside mb-4 space-y-2">
            <li>用开放式问题代替封闭式问题</li>
            <li>鼓励孩子对日常现象提出疑问</li>
            <li>与孩子一起寻找答案，而不是直接给出答案</li>
            <li>尊重孩子的每一个问题，即使看起来很简单</li>
          </ul>
          
          <h4 class="text-lg font-semibold mb-4">创造探索环境</h4>
          <p class="mb-4">在家中创造一个鼓励探索的环境：</p>
          <ul class="list-disc list-inside mb-4 space-y-2">
            <li>设立专门的探索角落，放置放大镜、科学工具等</li>
            <li>提供丰富的书籍和资料</li>
            <li>允许孩子进行安全的实验和尝试</li>
            <li>定期组织户外探索活动</li>
          </ul>
          
          <div class="bg-green-50 border-l-4 border-green-500 p-4 my-6">
            <h5 class="font-semibold text-green-800 mb-2">🎯 今日行动</h5>
            <p class="text-green-700">今天花10分钟时间，与孩子一起观察身边的一个自然现象（如树叶的脉络、蚂蚁的行为等），鼓励他们提出至少3个问题。</p>
          </div>
        </div>
      `
    },
    {
      id: 'article3',
      title: 'SMART原则：教孩子学会设定可实现的目标',
      author: '王博士',
      date: '2024-01-10',
      category: '目标设定',
      categoryColor: 'bg-yellow-100 text-yellow-800',
      summary: '学会设定目标是重要的生活技能。通过SMART原则（具体的、可衡量的、可实现的、相关的、有时限的），帮助孩子制定合理的目标，培养规划能力和执行力...',
      views: '789',
      likes: '54',
      comments: '6',
      imageUrl: 'https://s.coze.cn/image/OVC9MPdfxCM/',
      content: '<div>目标设定文章内容...</div>'
    },
    {
      id: 'article4',
      title: '情绪管理：帮助孩子认识和表达自己的感受',
      author: '刘专家',
      date: '2024-01-08',
      category: '情商培养',
      categoryColor: 'bg-purple-100 text-purple-800',
      summary: '良好的情绪管理能力是心理健康的基础。学习如何引导孩子识别不同的情绪，用恰当的方式表达感受，建立健康的情绪调节机制...',
      views: '1,123',
      likes: '78',
      comments: '15',
      imageUrl: 'https://s.coze.cn/image/i2xmTvAuwIk/',
      content: '<div>情商培养文章内容...</div>'
    },
    {
      id: 'article5',
      title: '积极反馈的艺术：如何表扬才能真正激励孩子',
      author: '陈老师',
      date: '2024-01-05',
      category: '育儿技巧',
      categoryColor: 'bg-red-100 text-red-800',
      summary: '表扬是一把双刃剑。错误的表扬方式可能会降低孩子的内在动机，而有效的表扬则能增强他们的自信心和努力意愿。学习具体、真诚的表扬技巧...',
      views: '1,567',
      likes: '103',
      comments: '22',
      imageUrl: 'https://s.coze.cn/image/BPHX_Kc6gxc/',
      content: '<div>育儿技巧文章内容...</div>'
    }
  ];

  // 筛选和排序文章
  const filteredAndSortedArticles = React.useMemo(() => {
    let filteredArticles = articlesData;

    // 按搜索词筛选
    if (articleSearchTerm) {
      filteredArticles = filteredArticles.filter(article =>
        article.title.toLowerCase().includes(articleSearchTerm.toLowerCase()) ||
        article.summary.toLowerCase().includes(articleSearchTerm.toLowerCase())
      );
    }

    // 按分类筛选
    if (selectedCategory) {
      const categoryMap: { [key: string]: string } = {
        'growth-mindset': '成长型思维',
        'curiosity': '好奇心培养',
        'goal-setting': '目标设定',
        'emotional-intelligence': '情商培养',
        'parenting-skills': '育儿技巧'
      };
      filteredArticles = filteredArticles.filter(article => 
        article.category === categoryMap[selectedCategory]
      );
    }

    // 排序
    const sortedArticles = [...filteredArticles].sort((a, b) => {
      switch (sortBy) {
        case 'publish_time':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'popularity':
          return parseInt(b.views.replace(',', '')) - parseInt(a.views.replace(',', ''));
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

    return sortedArticles;
  }, [articleSearchTerm, selectedCategory, sortBy]);

  // 处理文章点击
  const handleArticleClick = (article: Article) => {
    setSelectedArticle(article);
    setShowArticleModal(true);
  };

  // 关闭模态框
  const handleCloseModal = () => {
    setShowArticleModal(false);
    setSelectedArticle(null);
  };

  // 处理页面点击
  const handlePageClick = (page: number) => {
    setCurrentPage(page);
  };

  // 处理上一页/下一页
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    const totalPages = Math.ceil(filteredAndSortedArticles.length / pageSize);
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  // 处理每页显示数量变更
  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  // 处理刷新
  const handleRefresh = () => {
    // 这里可以添加刷新逻辑
    console.log('刷新页面');
  };

  // 处理全局搜索
  const handleGlobalSearch = (value: string) => {
    setGlobalSearchTerm(value);
    console.log('全局搜索：', value);
  };

  // 处理通知点击
  const handleNotificationClick = () => {
    console.log('查看通知');
  };

  // 计算分页信息
  const totalArticles = filteredAndSortedArticles.length;
  const totalPages = Math.ceil(totalArticles / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, totalArticles);
  const currentArticles = filteredAndSortedArticles.slice(startIndex, endIndex);

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                value={globalSearchTerm}
                onChange={(e) => handleGlobalSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button 
              onClick={handleNotificationClick}
              className="relative p-2 text-gray-600 hover:text-primary transition-colors"
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/kY9r5BicuaY/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full" 
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/SEDJ7Mo8V14/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover"
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} ${styles.active} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-manage" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">知识库</h2>
                <nav className="text-sm text-text-secondary">
                  <span>知识库</span>
                </nav>
              </div>
            </div>
          </div>

          {/* 工具栏区域 */}
          <section className="mb-6">
            <div className="bg-white rounded-2xl shadow-card p-4">
              <div className="flex flex-wrap items-center gap-4">
                {/* 搜索框 */}
                <div className="flex-1 min-w-64">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="搜索文章标题、内容..." 
                      value={articleSearchTerm}
                      onChange={(e) => setArticleSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  </div>
                </div>
                
                {/* 分类筛选 */}
                <div className="flex items-center space-x-2">
                  <label htmlFor="category-filter" className="text-sm font-medium text-text-secondary">分类：</label>
                  <select 
                    id="category-filter"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="">全部分类</option>
                    <option value="growth-mindset">成长型思维</option>
                    <option value="curiosity">好奇心培养</option>
                    <option value="goal-setting">目标设定</option>
                    <option value="emotional-intelligence">情商培养</option>
                    <option value="parenting-skills">育儿技巧</option>
                  </select>
                </div>
                
                {/* 排序选项 */}
                <div className="flex items-center space-x-2">
                  <label htmlFor="sort-filter" className="text-sm font-medium text-text-secondary">排序：</label>
                  <select 
                    id="sort-filter"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="publish_time">按发布时间</option>
                    <option value="popularity">按热门度</option>
                    <option value="title">按标题</option>
                  </select>
                </div>
                
                {/* 刷新按钮 */}
                <button 
                  onClick={handleRefresh}
                  className="p-2 text-gray-600 hover:text-primary transition-colors"
                >
                  <i className="fas fa-sync-alt"></i>
                </button>
              </div>
            </div>
          </section>

          {/* 文章列表 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">育儿知识文章</h3>
                <div className="text-sm text-text-secondary">
                  共 <span>{totalArticles}</span> 篇文章
                </div>
              </div>
              
              <div className="space-y-4">
                {currentArticles.map((article) => (
                  <div 
                    key={article.id}
                    onClick={() => handleArticleClick(article)}
                    className={`${styles.articleCard} border border-gray-200 rounded-lg p-4 hover:border-primary transition-all cursor-pointer`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${article.categoryColor}`}>
                            {article.category}
                          </span>
                          <span className="text-xs text-text-secondary">作者：{article.author}</span>
                          <span className="text-xs text-text-secondary">•</span>
                          <span className="text-xs text-text-secondary">{article.date}</span>
                        </div>
                        <h4 className="text-lg font-semibold text-text-primary mb-2 hover:text-primary transition-colors">
                          {article.title}
                        </h4>
                        <p className="text-sm text-text-secondary mb-3 line-clamp-2">
                          {article.summary}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-text-secondary">
                          <span><i className="fas fa-eye mr-1"></i>{article.views} 阅读</span>
                          <span><i className="fas fa-thumbs-up mr-1"></i>{article.likes} 点赞</span>
                          <span><i className="fas fa-comment mr-1"></i>{article.comments} 评论</span>
                        </div>
                      </div>
                      <div className="ml-4">
                        <img 
                          src={article.imageUrl} 
                          alt={`${article.category}文章配图`} 
                          className="w-24 h-16 rounded-lg object-cover"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 分页区域 */}
          <section>
            <div className="bg-white rounded-2xl shadow-card p-4">
              <div className="flex items-center justify-between">
                <div className="text-sm text-text-secondary">
                  显示第 <span>{startIndex + 1}</span> - <span>{endIndex}</span> 条，共 <span>{totalArticles}</span> 条记录
                </div>
                
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className="px-3 py-1 text-sm border border-gray-300 rounded-lg hover:border-primary hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <i className="fas fa-chevron-left mr-1"></i>上一页
                  </button>
                  
                  <div className="flex space-x-1">
                    {[1, 2, 3, '...', totalPages].map((page) => (
                      typeof page === 'number' ? (
                        <button
                          key={page}
                          onClick={() => handlePageClick(page)}
                          className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                            currentPage === page
                              ? 'bg-primary text-white'
                              : 'border border-gray-300 hover:border-primary hover:text-primary'
                          }`}
                        >
                          {page}
                        </button>
                      ) : (
                        <span key="ellipsis" className="px-3 py-1 text-sm text-text-secondary">...</span>
                      )
                    ))}
                  </div>
                  
                  <button 
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 text-sm border border-gray-300 rounded-lg hover:border-primary hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    下一页<i className="fas fa-chevron-right ml-1"></i>
                  </button>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-text-secondary">每页显示：</span>
                  <select 
                    value={pageSize}
                    onChange={(e) => handlePageSizeChange(Number(e.target.value))}
                    className="px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="50">50</option>
                  </select>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 文章详情模态弹窗 */}
      {showArticleModal && selectedArticle && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50"
          onClick={handleCloseModal}
        >
          <div className="flex items-center justify-center min-h-screen p-4">
            <div 
              className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white border-b border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-text-primary">{selectedArticle.title}</h3>
                  <button 
                    onClick={handleCloseModal}
                    className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <i className="fas fa-times text-lg"></i>
                  </button>
                </div>
                <div className="flex items-center space-x-4 mt-2 text-sm text-text-secondary">
                  <span>作者：{selectedArticle.author}</span>
                  <span>{selectedArticle.date}</span>
                  <span><i className="fas fa-eye mr-1"></i>{selectedArticle.views}</span>
                </div>
              </div>
              
              <div className="p-6">
                <div dangerouslySetInnerHTML={{ __html: selectedArticle.content }} />
              </div>
              
              <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:border-primary hover:text-primary transition-colors">
                      <i className="fas fa-thumbs-up"></i>
                      <span>点赞</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:border-primary hover:text-primary transition-colors">
                      <i className="fas fa-share"></i>
                      <span>分享</span>
                    </button>
                  </div>
                  <button className={`${styles.btnGradient} text-white px-6 py-2 rounded-lg text-sm font-medium`}>
                    收藏文章
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBasePage;

