

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface TaskData {
  title: string;
  description: string;
  goal: string;
  category: string;
  status: string;
  energy: string;
  creator: string;
  targetDate: string;
  completedDate: string | null;
}

interface CheckinRecord {
  id: string;
  userName: string;
  userAvatar: string;
  timestamp: string;
  content: string;
  images: string[];
  energy: string;
  badge?: string;
  feedback?: {
    authorName: string;
    authorAvatar: string;
    content: string;
    timestamp: string;
    emoji?: string;
  };
}

const TaskDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [taskData, setTaskData] = useState<TaskData>({
    title: '完成数学练习册第3章',
    description: '完成数学练习册第3章的所有练习题，包括选择题、填空题和应用题。重点掌握分数的加减法运算，确保每道题都理解解题思路。',
    goal: '熟练掌握分数加减法的计算方法，提高数学解题能力，为后续学习打下坚实基础。',
    category: '学习探索',
    status: '已完成',
    energy: '+50',
    creator: '小明',
    targetDate: '2024年1月15日',
    completedDate: '2024年1月14日'
  });

  const [checkinRecords] = useState<CheckinRecord[]>([
    {
      id: '1',
      userName: '小明',
      userAvatar: 'https://s.coze.cn/image/lpjrKsXeUBQ/',
      timestamp: '2024年1月14日 18:30',
      content: '今天的数学练习完成了！我学会了分数的加减法，特别是异分母分数的运算。虽然刚开始有点难，但多做几道题就明白了。',
      images: [
        'https://s.coze.cn/image/ujb-B9scjzw/',
        'https://s.coze.cn/image/rwgRKWQS2yQ/'
      ],
      energy: '+50能量',
      badge: '坚持不懈奖',
      feedback: {
        authorName: '妈妈',
        authorAvatar: 'https://s.coze.cn/image/9JpLx3Op7mw/',
        content: '太棒了！看到你认真完成数学练习，妈妈为你感到骄傲。坚持就是胜利，继续加油！',
        timestamp: '2024年1月14日 19:15',
        emoji: '🤗'
      }
    },
    {
      id: '2',
      userName: '小明',
      userAvatar: 'https://s.coze.cn/image/t6tOR_2U644/',
      timestamp: '2024年1月13日 17:45',
      content: '今天开始做第3章的练习，前面的基础题都比较简单，明天继续完成后面的应用题。',
      images: [
        'https://s.coze.cn/image/6rmk-oN8rp0/'
      ],
      energy: '+20能量',
      feedback: {
        authorName: '妈妈',
        authorAvatar: 'https://s.coze.cn/image/c5o_YFm77Fw/',
        content: '好的，注意做题要仔细审题，遇到困难可以问我哦！',
        timestamp: '2024年1月13日 18:20',
        emoji: '👍'
      }
    }
  ]);

  const [showImageModal, setShowImageModal] = useState(false);
  const [modalImageSrc, setModalImageSrc] = useState('');
  const [modalImageAlt, setModalImageAlt] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '任务详情 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    const taskId = searchParams.get('taskId');
    if (taskId) {
      loadTaskDetails(taskId);
    }
  }, [searchParams]);

  const loadTaskDetails = (taskId: string) => {
    const mockTasks: Record<string, TaskData> = {
      'task1': {
        title: '完成数学练习册第3章',
        description: '完成数学练习册第3章的所有练习题，包括选择题、填空题和应用题。重点掌握分数的加减法运算，确保每道题都理解解题思路。',
        goal: '熟练掌握分数加减法的计算方法，提高数学解题能力，为后续学习打下坚实基础。',
        category: '学习探索',
        status: '已完成',
        energy: '+50',
        creator: '小明',
        targetDate: '2024年1月15日',
        completedDate: '2024年1月14日'
      },
      'task2': {
        title: '每天阅读30分钟',
        description: '选择自己喜欢的书籍，每天坚持阅读30分钟，培养阅读习惯。',
        goal: '培养良好的阅读习惯，拓宽知识面，提高理解能力。',
        category: '习惯养成',
        status: '进行中',
        energy: '+30',
        creator: '小明',
        targetDate: '2024年1月20日',
        completedDate: null
      }
    };

    const task = mockTasks[taskId] || mockTasks['task1'];
    setTaskData(task);
  };

  const handleImageClick = (src: string, alt: string) => {
    setModalImageSrc(src);
    setModalImageAlt(alt);
    setShowImageModal(true);
  };

  const handleCloseImageModal = () => {
    setShowImageModal(false);
    setModalImageSrc('');
    setModalImageAlt('');
  };

  const handleDeleteClick = () => {
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = () => {
    console.log('删除任务');
    setShowDeleteModal(false);
    navigate('/task-list');
  };

  const handleCancelDelete = () => {
    setShowDeleteModal(false);
  };

  const handleEditTask = () => {
    const taskId = searchParams.get('taskId') || 'task1';
    navigate(`/task-create?taskId=${taskId}`);
  };

  const handleCheckin = () => {
    const taskId = searchParams.get('taskId') || 'task1';
    console.log('打开打卡弹窗', taskId);
  };

  const handleProvideFeedback = () => {
    const taskId = searchParams.get('taskId') || 'task1';
    console.log('打开家长反馈弹窗', taskId);
  };

  const handleBackToList = () => {
    navigate(-1);
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowImageModal(false);
      setShowDeleteModal(false);
    }
  };

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/iin634-v_j8/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/SLq5l0Gu9cE/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover"
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link to="/parent-dashboard" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link to="/task-list" className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}>
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link to="/wish-list" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link to="/family-honor-wall" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link to="/growth-report" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link to="/knowledge-base" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link to="/family-manage" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link to="/user-profile" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link to="/settings" className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}>
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">{taskData.title}</h2>
                <nav className="text-sm text-text-secondary">
                  <Link to="/task-list" className="hover:text-primary">任务</Link>
                  <span className="mx-2">/</span>
                  <span>任务详情</span>
                </nav>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={handleEditTask}
                  className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-edit mr-2"></i>编辑任务
                </button>
                <button 
                  onClick={handleDeleteClick}
                  className="bg-white border border-danger text-danger px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-50 transition-colors"
                >
                  <i className="fas fa-trash mr-2"></i>删除任务
                </button>
              </div>
            </div>
          </div>

          {/* 任务基本信息区 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-book text-blue-600 text-xl"></i>
                  </div>
                  <p className="text-sm font-medium text-text-secondary">任务分类</p>
                  <p className="text-lg font-semibold text-text-primary">{taskData.category}</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-check-circle text-green-600 text-xl"></i>
                  </div>
                  <p className="text-sm font-medium text-text-secondary">任务状态</p>
                  <p className={`text-lg font-semibold ${taskData.status === '已完成' ? 'text-green-600' : 'text-blue-600'}`}>
                    {taskData.status}
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-star text-yellow-600 text-xl"></i>
                  </div>
                  <p className="text-sm font-medium text-text-secondary">能量值</p>
                  <p className="text-lg font-semibold text-text-primary">{taskData.energy}</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-user text-purple-600 text-xl"></i>
                  </div>
                  <p className="text-sm font-medium text-text-secondary">创建者</p>
                  <p className="text-lg font-semibold text-text-primary">{taskData.creator}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-text-primary mb-4">任务描述</h3>
                  <p className="text-text-secondary leading-relaxed">
                    {taskData.description}
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-text-primary mb-4">任务目标</h3>
                  <p className="text-text-secondary leading-relaxed">
                    {taskData.goal}
                  </p>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm font-medium text-text-secondary">计划完成时间</p>
                    <p className="text-lg font-semibold text-text-primary">{taskData.targetDate}</p>
                  </div>
                  {taskData.completedDate && (
                    <div>
                      <p className="text-sm font-medium text-text-secondary">实际完成时间</p>
                      <p className="text-lg font-semibold text-green-600">{taskData.completedDate}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>

          {/* 打卡记录区 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-text-primary">打卡记录</h3>
                <button 
                  onClick={handleCheckin}
                  className={`${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-plus mr-2"></i>打卡任务
                </button>
              </div>
              
              <div className="space-y-6">
                {checkinRecords.map((record, index) => (
                  <div key={record.id} className={`${styles.timelineItem} ${index === checkinRecords.length - 1 ? 'last:border-b-0' : ''}`}>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <img 
                            src={record.userAvatar} 
                            alt={`${record.userName}头像`} 
                            className="w-10 h-10 rounded-full"
                          />
                          <div>
                            <p className="font-medium text-text-primary">{record.userName}</p>
                            <p className="text-sm text-text-secondary">{record.timestamp}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`${styles.energyBadge} text-white text-xs px-2 py-1 rounded-full`}>
                            {record.energy}
                          </span>
                          {record.badge && (
                            <span className={`${styles.badgeIcon} text-white text-xs px-2 py-1 rounded-full`}>
                              <i className="fas fa-trophy mr-1"></i>{record.badge}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-text-secondary mb-3">
                          {record.content}
                        </p>
                        <div className={`grid ${record.images.length === 2 ? 'grid-cols-2' : 'grid-cols-1'} gap-2`}>
                          {record.images.map((imageSrc, imageIndex) => (
                            <img 
                              key={imageIndex}
                              src={imageSrc} 
                              alt={`打卡照片${imageIndex + 1}`} 
                              className="w-full h-32 object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                              onClick={() => handleImageClick(imageSrc, `打卡照片${imageIndex + 1}`)}
                            />
                          ))}
                        </div>
                      </div>
                      
                      {/* 家长反馈 */}
                      {record.feedback && (
                        <div className="bg-blue-50 rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <img 
                              src={record.feedback.authorAvatar} 
                              alt={`${record.feedback.authorName}头像`} 
                              className="w-8 h-8 rounded-full"
                            />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="font-medium text-text-primary">{record.feedback.authorName}</span>
                                <span className="text-sm text-text-secondary">{record.feedback.timestamp}</span>
                                {record.feedback.emoji && <span className="text-2xl">{record.feedback.emoji}</span>}
                              </div>
                              <p className="text-text-secondary">
                                {record.feedback.content}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 操作按钮区 */}
          <section className="mb-8">
            <div className="bg-white rounded-2xl shadow-card p-6">
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={handleProvideFeedback}
                  className={`${styles.btnGradient} text-white px-6 py-3 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-comment-dots mr-2"></i>提供反馈
                </button>
                <Link 
                  to="/family-honor-wall"
                  className="bg-white border border-gray-300 text-gray-700 px-6 py-3 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-trophy mr-2"></i>查看荣誉墙
                </Link>
                <button 
                  onClick={handleBackToList}
                  className="bg-white border border-gray-300 text-gray-700 px-6 py-3 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-arrow-left mr-2"></i>返回列表
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 图片预览模态框 */}
      {showImageModal && (
        <div 
          className={`fixed inset-0 z-50 ${styles.modalBackdrop}`}
          onClick={handleCloseImageModal}
        >
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="relative">
              <img 
                src={modalImageSrc} 
                alt={modalImageAlt} 
                className="max-w-full max-h-full rounded-lg shadow-2xl"
              />
              <button 
                onClick={handleCloseImageModal}
                className="absolute top-4 right-4 w-8 h-8 bg-black bg-opacity-50 text-white rounded-full flex items-center justify-center hover:bg-opacity-70 transition-colors"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 确认删除模态框 */}
      {showDeleteModal && (
        <div 
          className={`fixed inset-0 z-50 ${styles.modalBackdrop}`}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              handleCancelDelete();
            }
          }}
        >
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className={`bg-white rounded-2xl shadow-2xl p-6 max-w-md w-full ${styles.modalContent}`}>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">确认删除任务</h3>
                <p className="text-text-secondary mb-6">删除后将无法恢复，确定要删除这个任务吗？</p>
                <div className="flex space-x-3">
                  <button 
                    onClick={handleConfirmDelete}
                    className="flex-1 bg-red-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-red-600 transition-colors"
                  >
                    确认删除
                  </button>
                  <button 
                    onClick={handleCancelDelete}
                    className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                  >
                    取消
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskDetailPage;

