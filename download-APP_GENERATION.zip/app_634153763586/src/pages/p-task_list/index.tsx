

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { Task, SortOption } from './types';

const TaskListPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 模拟任务数据
  const mockTasks: Task[] = [
    {
      id: 'task1',
      name: '每天阅读30分钟',
      description: '培养良好的阅读习惯，每天坚持阅读30分钟',
      category: 'habit',
      status: 'progress',
      targetDate: '2024-03-15',
      energy: 20,
      creator: '小明',
      creatorRole: 'child'
    },
    {
      id: 'task2',
      name: '完成数学练习册第3章',
      description: '巩固数学知识，完成练习册第3章的所有题目',
      category: 'learning',
      status: 'completed',
      targetDate: '2024-03-12',
      energy: 15,
      creator: '妈妈',
      creatorRole: 'parent'
    },
    {
      id: 'task3',
      name: '学习骑自行车',
      description: '学会独立骑自行车，掌握基本的平衡技巧',
      category: 'skill',
      status: 'pending',
      targetDate: '2024-03-20',
      energy: 30,
      creator: '小明',
      creatorRole: 'child'
    },
    {
      id: 'task4',
      name: '整理自己的房间',
      description: '保持房间整洁，每天整理床铺和书桌',
      category: 'family',
      status: 'confirmed',
      targetDate: '2024-03-10',
      energy: 10,
      creator: '爸爸',
      creatorRole: 'parent'
    },
    {
      id: 'task5',
      name: '练习钢琴30分钟',
      description: '每天练习钢琴，提高音乐技能',
      category: 'skill',
      status: 'progress',
      targetDate: '2024-03-18',
      energy: 25,
      creator: '小明',
      creatorRole: 'child'
    },
    {
      id: 'task6',
      name: '帮助妈妈做家务',
      description: '分担家庭责任，每天帮助妈妈做一件家务',
      category: 'family',
      status: 'completed',
      targetDate: '2024-03-11',
      energy: 12,
      creator: '妈妈',
      creatorRole: 'parent'
    },
    {
      id: 'task7',
      name: '科学实验小项目',
      description: '完成学校布置的科学实验作业',
      category: 'learning',
      status: 'confirmed',
      targetDate: '2024-03-16',
      energy: 22,
      creator: '爸爸',
      creatorRole: 'parent'
    },
    {
      id: 'task8',
      name: '每天喝水8杯',
      description: '养成良好的饮水习惯，保持身体健康',
      category: 'habit',
      status: 'progress',
      targetDate: '2024-03-25',
      energy: 8,
      creator: '小明',
      creatorRole: 'child'
    }
  ];

  // 状态管理
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([...mockTasks]);
  const [selectedTasks, setSelectedTasks] = useState<Set<string>>(new Set());
  const [taskSearch, setTaskSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [sortSelect, setSortSelect] = useState<SortOption>('time-desc');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '我的任务 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  // 应用筛选
  const applyFilters = () => {
    let filtered = [...mockTasks];
    
    // 搜索筛选
    if (taskSearch) {
      filtered = filtered.filter(task => 
        task.name.toLowerCase().includes(taskSearch.toLowerCase())
      );
    }
    
    // 状态筛选
    if (statusFilter) {
      filtered = filtered.filter(task => task.status === statusFilter);
    }
    
    // 分类筛选
    if (categoryFilter) {
      filtered = filtered.filter(task => task.category === categoryFilter);
    }
    
    // 排序
    sortTasks(filtered, sortSelect);
    
    setFilteredTasks(filtered);
    setCurrentPage(1);
  };

  // 排序任务
  const sortTasks = (tasks: Task[], sortValue: SortOption) => {
    switch(sortValue) {
      case 'time-desc':
        tasks.sort((a, b) => new Date(b.targetDate).getTime() - new Date(a.targetDate).getTime());
        break;
      case 'time-asc':
        tasks.sort((a, b) => new Date(a.targetDate).getTime() - new Date(b.targetDate).getTime());
        break;
      case 'energy-desc':
        tasks.sort((a, b) => b.energy - a.energy);
        break;
      case 'energy-asc':
        tasks.sort((a, b) => a.energy - b.energy);
        break;
      case 'name-asc':
        tasks.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'category-asc':
        tasks.sort((a, b) => a.category.localeCompare(b.category));
        break;
      case 'status-asc':
        tasks.sort((a, b) => a.status.localeCompare(b.status));
        break;
      case 'creator-asc':
        tasks.sort((a, b) => a.creator.localeCompare(b.creator));
        break;
    }
  };

  // 处理搜索
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTaskSearch(e.target.value);
  };

  // 处理筛选
  const handleFilterChange = () => {
    applyFilters();
  };

  // 处理排序
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortSelect(e.target.value as SortOption);
  };

  // 处理表格排序
  const handleTableSort = (field: string) => {
    let sortValue: SortOption = 'time-desc';
    switch(field) {
      case 'name':
        sortValue = 'name-asc';
        break;
      case 'category':
        sortValue = 'category-asc';
        break;
      case 'status':
        sortValue = 'status-asc';
        break;
      case 'target-date':
        sortValue = 'time-asc';
        break;
      case 'energy':
        sortValue = 'energy-asc';
        break;
      case 'creator':
        sortValue = 'creator-asc';
        break;
    }
    setSortSelect(sortValue);
  };

  // 处理全选
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = e.target.checked;
    const currentPageTasks = getCurrentPageTasks();
    
    if (isChecked) {
      const currentPageIds = new Set(currentPageTasks.map(task => task.id));
      setSelectedTasks(currentPageIds);
    } else {
      const newSelected = new Set(selectedTasks);
      currentPageTasks.forEach(task => newSelected.delete(task.id));
      setSelectedTasks(newSelected);
    }
  };

  // 处理任务选择
  const handleTaskSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const taskId = e.target.value;
    const newSelected = new Set(selectedTasks);
    
    if (e.target.checked) {
      newSelected.add(taskId);
    } else {
      newSelected.delete(taskId);
    }
    
    setSelectedTasks(newSelected);
  };

  // 处理批量删除
  const handleBatchDelete = () => {
    if (selectedTasks.size === 0) return;
    
    if (confirm(`确定要删除选中的 ${selectedTasks.size} 个任务吗？`)) {
      // 从模拟数据中删除任务（这里只是模拟，实际项目中应该调用API）
      selectedTasks.forEach(taskId => {
        const index = mockTasks.findIndex(task => task.id === taskId);
        if (index !== -1) {
          mockTasks.splice(index, 1);
        }
      });
      
      setSelectedTasks(new Set());
      applyFilters();
      alert('任务删除成功！');
    }
  };

  // 处理任务删除
  const handleDeleteTask = (taskId: string) => {
    if (confirm('确定要删除这个任务吗？')) {
      const index = mockTasks.findIndex(task => task.id === taskId);
      if (index !== -1) {
        mockTasks.splice(index, 1);
        applyFilters();
        alert('任务删除成功！');
      }
    }
  };

  // 处理翻页
  const changePage = (page: number) => {
    const totalPages = Math.ceil(filteredTasks.length / pageSize);
    if (page < 1 || page > totalPages) return;
    
    setCurrentPage(page);
  };

  // 刷新任务列表
  const refreshTasks = () => {
    applyFilters();
    alert('任务列表已刷新！');
  };

  // 获取当前页任务
  const getCurrentPageTasks = () => {
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, filteredTasks.length);
    return filteredTasks.slice(startIndex, endIndex);
  };

  // 获取分类文本
  const getCategoryText = (category: string) => {
    const categoryMap: Record<string, string> = {
      'habit': '习惯养成',
      'learning': '学习探索',
      'skill': '兴趣技能',
      'family': '家庭贡献'
    };
    return categoryMap[category] || category;
  };

  // 获取状态文本
  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      'pending': '待确认',
      'confirmed': '待执行',
      'progress': '进行中',
      'completed': '已完成',
      'rejected': '已拒绝'
    };
    return statusMap[status] || status;
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN');
  };

  // 检查是否全选
  const isAllSelected = () => {
    const currentPageTasks = getCurrentPageTasks();
    if (currentPageTasks.length === 0) return false;
    return currentPageTasks.every(task => selectedTasks.has(task.id));
  };

  // 检查是否部分选中
  const isIndeterminate = () => {
    const currentPageTasks = getCurrentPageTasks();
    const selectedCount = currentPageTasks.filter(task => selectedTasks.has(task.id)).length;
    return selectedCount > 0 && selectedCount < currentPageTasks.length;
  };

  // 监听筛选条件变化
  useEffect(() => {
    applyFilters();
  }, [taskSearch, statusFilter, categoryFilter, sortSelect]);

  const currentPageTasks = getCurrentPageTasks();
  const totalPages = Math.ceil(filteredTasks.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize + 1;
  const endIndex = Math.min(currentPage * pageSize, filteredTasks.length);

  // 生成页码按钮
  const renderPageNumbers = () => {
    const pages = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
        pages.push(
          <button
            key={i}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              i === currentPage 
                ? 'bg-primary text-white' 
                : 'border border-gray-300 text-gray-700 hover:border-primary hover:text-primary'
            }`}
            onClick={() => changePage(i)}
          >
            {i}
          </button>
        );
      } else if (i === currentPage - 2 || i === currentPage + 2) {
        pages.push(
          <span key={`ellipsis-${i}`} className="px-2 text-gray-400">
            ...
          </span>
        );
      }
    }
    return pages;
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/dmchHNOIXhw/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full" 
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/ZZbbbn9W3sA/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover" 
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-manage" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">我的任务</h2>
                <nav className="text-sm text-text-secondary">
                  <span>任务</span>
                </nav>
              </div>
              <div className="flex space-x-3">
                <Link 
                  to="/task-create"
                  className={`${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-plus mr-2"></i>创建任务
                </Link>
                <button 
                  onClick={refreshTasks}
                  className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:border-primary transition-colors"
                >
                  <i className="fas fa-sync-alt mr-2"></i>刷新
                </button>
              </div>
            </div>
          </div>

          {/* 工具栏区域 */}
          <div className="bg-white rounded-2xl shadow-card p-4 mb-6">
            <div className="flex flex-wrap items-center gap-4">
              {/* 搜索框 */}
              <div className="flex-1 min-w-64">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="搜索任务名称..." 
                    value={taskSearch}
                    onChange={handleSearch}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>
              
              {/* 状态筛选 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">状态:</label>
                <select 
                  value={statusFilter}
                  onChange={(e) => {
                    setStatusFilter(e.target.value);
                    handleFilterChange();
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">全部状态</option>
                  <option value="pending">待确认</option>
                  <option value="confirmed">待执行</option>
                  <option value="progress">进行中</option>
                  <option value="completed">已完成</option>
                  <option value="rejected">已拒绝</option>
                </select>
              </div>
              
              {/* 分类筛选 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">分类:</label>
                <select 
                  value={categoryFilter}
                  onChange={(e) => {
                    setCategoryFilter(e.target.value);
                    handleFilterChange();
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">全部分类</option>
                  <option value="habit">习惯养成</option>
                  <option value="learning">学习探索</option>
                  <option value="skill">兴趣技能</option>
                  <option value="family">家庭贡献</option>
                </select>
              </div>
              
              {/* 排序选项 */}
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">排序:</label>
                <select 
                  value={sortSelect}
                  onChange={handleSortChange}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="time-desc">按时间降序</option>
                  <option value="time-asc">按时间升序</option>
                  <option value="energy-desc">按能量值降序</option>
                  <option value="energy-asc">按能量值升序</option>
                </select>
              </div>
              
              {/* 批量操作 */}
              {selectedTasks.size > 0 && (
                <div>
                  <button 
                    onClick={handleBatchDelete}
                    className="bg-danger text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-600 transition-colors"
                  >
                    <i className="fas fa-trash mr-2"></i>批量删除
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* 数据展示区域 */}
          <section className="mb-6">
            <div className="bg-white rounded-2xl shadow-card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-3 px-4 w-10">
                        <input 
                          type="checkbox" 
                          checked={isAllSelected()}
                          ref={(input) => {
                            if (input) input.indeterminate = isIndeterminate();
                          }}
                          onChange={handleSelectAll}
                          className="rounded border-gray-300 text-primary focus:ring-primary"
                        />
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('name')}
                      >
                        任务名称 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('category')}
                      >
                        分类 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('status')}
                      >
                        状态 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('target-date')}
                      >
                        计划完成时间 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('energy')}
                      >
                        能量值 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th 
                        className="text-left py-3 px-4 text-sm font-medium text-text-secondary cursor-pointer hover:text-primary"
                        onClick={() => handleTableSort('creator')}
                      >
                        创建者 <i className="fas fa-sort ml-1"></i>
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-text-secondary">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentPageTasks.map(task => (
                      <tr key={task.id} className={`${styles.tableRow} border-b border-gray-100`}>
                        <td className="py-3 px-4">
                          <input 
                            type="checkbox" 
                            value={task.id}
                            checked={selectedTasks.has(task.id)}
                            onChange={handleTaskSelect}
                            className="rounded border-gray-300 text-primary focus:ring-primary"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <Link 
                            to={`/task-detail?taskId=${task.id}`}
                            className="text-primary hover:underline font-medium"
                          >
                            {task.name}
                          </Link>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`${styles[`categoryBadge${task.category.charAt(0).toUpperCase() + task.category.slice(1)}`]} inline-flex items-center px-2 py-1 rounded-full text-xs font-medium`}>
                            {getCategoryText(task.category)}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`${styles[`statusBadge${task.status.charAt(0).toUpperCase() + task.status.slice(1)}`]} inline-flex items-center px-2 py-1 rounded-full text-xs font-medium`}>
                            {getStatusText(task.status)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm text-text-secondary">
                          {formatDate(task.targetDate)}
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-lg font-bold text-primary">{task.energy}</span>
                        </td>
                        <td className="py-3 px-4 text-sm text-text-secondary">
                          {task.creator}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <Link 
                              to={`/task-create?taskId=${task.id}`}
                              className="text-primary hover:text-blue-700 text-sm" 
                              title="编辑"
                            >
                              <i className="fas fa-edit"></i>
                            </Link>
                            <button 
                              onClick={() => handleDeleteTask(task.id)}
                              className="text-danger hover:text-red-700 text-sm" 
                              title="删除"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                            {task.status === 'progress' && (
                              <button 
                                onClick={() => alert('打卡功能演示 - 实际项目中会打开打卡弹窗')}
                                className="text-success hover:text-green-700 text-sm" 
                                title="打卡"
                              >
                                <i className="fas fa-check-circle"></i>
                              </button>
                            )}
                            {task.status === 'completed' && (
                              <button 
                                onClick={() => alert('反馈功能演示 - 实际项目中会打开反馈弹窗')}
                                className="text-secondary hover:text-yellow-700 text-sm" 
                                title="提供反馈"
                              >
                                <i className="fas fa-comment-dots"></i>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {/* 空状态 */}
              {filteredTasks.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-tasks text-gray-400 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-text-primary mb-2">暂无任务</h3>
                  <p className="text-text-secondary mb-6">创建您的第一个任务，开始孩子的成长之旅</p>
                  <Link 
                    to="/task-create"
                    className={`${styles.btnGradient} text-white px-6 py-2 rounded-lg text-sm font-medium inline-flex items-center`}
                  >
                    <i className="fas fa-plus mr-2"></i>创建任务
                  </Link>
                </div>
              )}
            </div>
          </section>

          {/* 分页区域 */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-text-secondary">
              显示 <span>{filteredTasks.length > 0 ? startIndex : 0}</span> - <span>{endIndex}</span> 条，共 <span>{filteredTasks.length}</span> 条记录
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => changePage(currentPage - 1)}
                disabled={currentPage <= 1}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-primary hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <i className="fas fa-chevron-left"></i>
              </button>
              <div className="flex space-x-1">
                {renderPageNumbers()}
              </div>
              <button 
                onClick={() => changePage(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-primary hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <i className="fas fa-chevron-right"></i>
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default TaskListPage;

