

export interface Task {
  id: string;
  name: string;
  description: string;
  category: 'habit' | 'learning' | 'skill' | 'family';
  status: 'pending' | 'confirmed' | 'progress' | 'completed' | 'rejected';
  targetDate: string;
  energy: number;
  creator: string;
  creatorRole: 'child' | 'parent';
}

export type SortOption = 'time-desc' | 'time-asc' | 'energy-desc' | 'energy-asc' | 'name-asc' | 'category-asc' | 'status-asc' | 'creator-asc';

