

import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface ProfileFormData {
  nickname: string;
  gender: 'male' | 'female';
  birthday: string;
  phone: string;
  email: string;
}

interface PasswordFormData {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

const UserProfilePage: React.FC = () => {
  // 页面标题设置
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '个人资料 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  // 表单状态
  const [profileFormData, setProfileFormData] = useState<ProfileFormData>({
    nickname: '张爸爸',
    gender: 'male',
    birthday: '1985-06-15',
    phone: '138****8888',
    email: 'zhang****@example.com'
  });

  // 原始数据用于取消操作
  const [originalProfileData, setOriginalProfileData] = useState<ProfileFormData>(profileFormData);

  // UI状态
  const [isChangePasswordModalVisible, setIsChangePasswordModalVisible] = useState(false);
  const [isSuccessToastVisible, setIsSuccessToastVisible] = useState(false);
  const [successToastMessage, setSuccessToastMessage] = useState('个人资料修改成功！');
  const [successToastType, setSuccessToastType] = useState<'success' | 'info'>('success');
  const [isSaving, setIsSaving] = useState(false);
  const [avatarSrc, setAvatarSrc] = useState('https://s.coze.cn/image/wAlrLFNGl1c/');

  // 密码表单状态
  const [passwordFormData, setPasswordFormData] = useState<PasswordFormData>({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // 文件输入引用
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // 处理头像上传
  const handleAvatarUploadClick = () => {
    avatarInputRef.current?.click();
  };

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setAvatarSrc(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // 处理表单输入变化
  const handleProfileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // 处理单选框变化
  const handleGenderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfileFormData(prev => ({
      ...prev,
      gender: e.target.value as 'male' | 'female'
    }));
  };

  // 显示成功提示
  const showSuccessToast = (message: string, type: 'success' | 'info' = 'success') => {
    setSuccessToastMessage(message);
    setSuccessToastType(type);
    setIsSuccessToastVisible(true);
    setTimeout(() => {
      setIsSuccessToastVisible(false);
    }, 3000);
  };

  // 处理表单提交
  const handleProfileFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    setIsSaving(true);

    // 模拟保存过程
    setTimeout(() => {
      setIsSaving(false);
      setOriginalProfileData(profileFormData);
      showSuccessToast('个人资料修改成功！');
    }, 1000);
  };

  // 处理取消操作
  const handleCancelClick = () => {
    setProfileFormData(originalProfileData);
    showSuccessToast('已放弃修改', 'info');
  };

  // 处理修改密码
  const handleChangePasswordClick = () => {
    setIsChangePasswordModalVisible(true);
  };

  const handleClosePasswordModal = () => {
    setIsChangePasswordModalVisible(false);
    setPasswordFormData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const handlePasswordInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePasswordFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordFormData.newPassword !== passwordFormData.confirmPassword) {
      alert('新密码和确认密码不一致');
      return;
    }

    if (passwordFormData.newPassword.length < 6) {
      alert('密码长度不能少于6位');
      return;
    }

    setIsChangingPassword(true);

    // 模拟修改密码过程
    setTimeout(() => {
      setIsChangingPassword(false);
      handleClosePasswordModal();
      showSuccessToast('密码修改成功！');
    }, 1000);
  };

  // 处理其他安全设置项点击
  const handleBindPhoneClick = () => {
    alert('手机号已绑定，如需更换请联系客服');
  };

  const handleBindEmailClick = () => {
    alert('邮箱已绑定，如需更换请联系客服');
  };

  const handleTwoFactorAuthClick = () => {
    alert('两步验证功能开发中，敬请期待');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            
            {/* 快速切换孩子 */}
            <div className="relative">
              <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/-N3tS9QRRJA/" 
                  alt="小明头像" 
                  className="w-8 h-8 rounded-full" 
                />
                <span className="text-sm">小明</span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
            </div>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/EWAJ42PYbOw/" 
                  alt="家长头像" 
                  className="w-full h-full object-cover" 
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-manage" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">个人资料</h2>
                <nav className="text-sm text-text-secondary">
                  <span>个人资料</span>
                </nav>
              </div>
            </div>
          </div>

          {/* 个人资料表单 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* 左侧：基本信息 */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl shadow-card p-6 mb-6">
                <h3 className="text-lg font-semibold text-text-primary mb-6">基本信息</h3>
                <form onSubmit={handleProfileFormSubmit} className="space-y-6">
                  {/* 头像上传 */}
                  <div className="flex items-center space-x-6">
                    <div className="relative">
                      <div 
                        onClick={handleAvatarUploadClick}
                        className={`${styles.avatarUploadArea} w-24 h-24 rounded-full overflow-hidden border-4 border-gray-200`}
                      >
                        <img 
                          src={avatarSrc}
                          alt="用户头像" 
                          className="w-full h-full object-cover"
                        />
                        <div className={`${styles.avatarOverlay} text-center`}>
                          <i className="fas fa-camera text-sm"></i>
                        </div>
                      </div>
                      <input 
                        type="file" 
                        ref={avatarInputRef}
                        accept="image/*" 
                        onChange={handleAvatarFileChange}
                        className="hidden"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-text-primary">点击头像更换照片</p>
                      <p className="text-xs text-text-secondary">支持 JPG、PNG 格式，文件大小不超过 2MB</p>
                    </div>
                  </div>

                  {/* 昵称 */}
                  <div className="space-y-2">
                    <label htmlFor="nickname" className="block text-sm font-medium text-text-primary">昵称 *</label>
                    <input 
                      type="text" 
                      id="nickname" 
                      name="nickname" 
                      value={profileFormData.nickname}
                      onChange={handleProfileInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                      required
                    />
                  </div>

                  {/* 性别 */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-text-primary">性别</label>
                    <div className="flex space-x-4">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="gender" 
                          value="male" 
                          checked={profileFormData.gender === 'male'}
                          onChange={handleGenderChange}
                          className="text-primary focus:ring-primary"
                        />
                        <span className="text-sm text-text-primary">男</span>
                      </label>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="gender" 
                          value="female" 
                          checked={profileFormData.gender === 'female'}
                          onChange={handleGenderChange}
                          className="text-primary focus:ring-primary"
                        />
                        <span className="text-sm text-text-primary">女</span>
                      </label>
                    </div>
                  </div>

                  {/* 生日 */}
                  <div className="space-y-2">
                    <label htmlFor="birthday" className="block text-sm font-medium text-text-primary">生日</label>
                    <input 
                      type="date" 
                      id="birthday" 
                      name="birthday" 
                      value={profileFormData.birthday}
                      onChange={handleProfileInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                    />
                  </div>

                  {/* 手机号 */}
                  <div className="space-y-2">
                    <label htmlFor="phone" className="block text-sm font-medium text-text-primary">手机号 *</label>
                    <input 
                      type="tel" 
                      id="phone" 
                      name="phone" 
                      value={profileFormData.phone}
                      readOnly
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                    />
                    <p className="text-xs text-text-secondary">手机号不可修改，如需更换请联系客服</p>
                  </div>

                  {/* 邮箱 */}
                  <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-medium text-text-primary">邮箱</label>
                    <input 
                      type="email" 
                      id="email" 
                      name="email" 
                      value={profileFormData.email}
                      onChange={handleProfileInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                    />
                  </div>
                </form>
              </div>
            </div>

            {/* 右侧：安全设置 */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-card p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-6">安全设置</h3>
                <div className="space-y-4">
                  {/* 修改密码 */}
                  <div 
                    onClick={handleChangePasswordClick}
                    className={`${styles.securityItem} flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer transition-all`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-key text-blue-600"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">修改密码</p>
                        <p className="text-xs text-text-secondary">定期更换密码保护账户安全</p>
                      </div>
                    </div>
                    <i className="fas fa-chevron-right text-gray-400"></i>
                  </div>

                  {/* 绑定手机 */}
                  <div 
                    onClick={handleBindPhoneClick}
                    className={`${styles.securityItem} flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer transition-all`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-mobile-alt text-green-600"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">绑定手机</p>
                        <p className="text-xs text-text-secondary">已绑定：138****8888</p>
                      </div>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <i className="fas fa-check mr-1"></i>已绑定
                    </span>
                  </div>

                  {/* 绑定邮箱 */}
                  <div 
                    onClick={handleBindEmailClick}
                    className={`${styles.securityItem} flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer transition-all`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-envelope text-yellow-600"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">绑定邮箱</p>
                        <p className="text-xs text-text-secondary">zhang****@example.com</p>
                      </div>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <i className="fas fa-check mr-1"></i>已绑定
                    </span>
                  </div>

                  {/* 两步验证 */}
                  <div 
                    onClick={handleTwoFactorAuthClick}
                    className={`${styles.securityItem} flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer transition-all`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-shield-alt text-orange-600"></i>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">两步验证</p>
                        <p className="text-xs text-text-secondary">开启后登录更安全</p>
                      </div>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      <i className="fas fa-circle mr-1"></i>未开启
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 操作按钮区 */}
          <div className="flex justify-end space-x-4 mt-8">
            <button 
              type="button" 
              onClick={handleCancelClick}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors"
            >
              取消
            </button>
            <button 
              type="submit" 
              onClick={handleProfileFormSubmit}
              disabled={isSaving}
              className={`${styles.btnGradient} text-white px-6 py-2 rounded-lg text-sm font-medium`}
            >
              {isSaving ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>保存中...
                </>
              ) : (
                <>
                  <i className="fas fa-save mr-2"></i>保存修改
                </>
              )}
            </button>
          </div>
        </main>
      </div>

      {/* 修改密码弹窗 */}
      {isChangePasswordModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-card max-w-md w-full">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-text-primary">修改密码</h3>
                  <button 
                    onClick={handleClosePasswordModal}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <form onSubmit={handlePasswordFormSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="current-password" className="block text-sm font-medium text-text-primary mb-2">当前密码</label>
                    <input 
                      type="password" 
                      id="current-password" 
                      name="currentPassword" 
                      value={passwordFormData.currentPassword}
                      onChange={handlePasswordInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="new-password" className="block text-sm font-medium text-text-primary mb-2">新密码</label>
                    <input 
                      type="password" 
                      id="new-password" 
                      name="newPassword" 
                      value={passwordFormData.newPassword}
                      onChange={handlePasswordInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-text-primary mb-2">确认新密码</label>
                    <input 
                      type="password" 
                      id="confirm-password" 
                      name="confirmPassword" 
                      value={passwordFormData.confirmPassword}
                      onChange={handlePasswordInputChange}
                      className={`w-full px-4 py-2 border border-gray-300 rounded-lg ${styles.formInputFocus}`}
                      required
                    />
                  </div>
                  <div className="flex space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={handleClosePasswordModal}
                      className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      disabled={isChangingPassword}
                      className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                    >
                      {isChangingPassword ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>修改中...
                        </>
                      ) : (
                        '确认修改'
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 成功提示 */}
      <div 
        className={`fixed top-20 right-6 px-6 py-3 rounded-lg shadow-lg z-50 ${
          successToastType === 'success' ? 'bg-success' : 'bg-info'
        } text-white ${styles.successToast} ${
          isSuccessToastVisible ? styles.successToastVisible : ''
        }`}
      >
        <div className="flex items-center space-x-2">
          <i className={`fas ${successToastType === 'success' ? 'fa-check-circle' : 'fa-undo'}`}></i>
          <span>{successToastMessage}</span>
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;

