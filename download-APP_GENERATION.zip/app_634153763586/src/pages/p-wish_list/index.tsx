

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';
import { Wish, SortOption } from './types';

const WishListPage: React.FC = () => {
  // 模拟心愿数据
  const [wishesData, setWishesData] = useState<Wish[]>([
    {
      id: 'wish1',
      name: '想要一个新的乐高积木',
      description: '我想要最新的城市系列乐高积木，可以搭建一个警察局。',
      requiredEnergy: 500,
      currentEnergy: 1240,
      status: 'approved',
      statusText: '待实现',
      createdAt: '2024-01-15',
      canApply: true
    },
    {
      id: 'wish2',
      name: '周末去游乐园',
      description: '希望周末能和爸爸妈妈一起去游乐园玩过山车。',
      requiredEnergy: 300,
      currentEnergy: 1240,
      status: 'pending',
      statusText: '待审核',
      createdAt: '2024-01-12',
      canApply: false
    },
    {
      id: 'wish3',
      name: '买一本科学实验书',
      description: '想要一本有趣的科学实验书，学习做各种小实验。',
      requiredEnergy: 150,
      currentEnergy: 1240,
      status: 'achieved',
      statusText: '已实现',
      createdAt: '2024-01-10',
      canApply: false
    },
    {
      id: 'wish4',
      name: '养一只小仓鼠',
      description: '希望能养一只可爱的小仓鼠作为宠物。',
      requiredEnergy: 800,
      currentEnergy: 1240,
      status: 'rejected',
      statusText: '已拒绝',
      createdAt: '2024-01-08',
      canApply: false
    },
    {
      id: 'wish5',
      name: '买一双新运动鞋',
      description: '我的运动鞋已经小了，需要一双新的运动鞋。',
      requiredEnergy: 400,
      currentEnergy: 1240,
      status: 'approved',
      statusText: '待实现',
      createdAt: '2024-01-05',
      canApply: true
    }
  ]);

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [filteredData, setFilteredData] = useState<Wish[]>([...wishesData]);
  const [selectedWishes, setSelectedWishes] = useState<Set<string>>(new Set());
  const [statusFilter, setStatusFilter] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('created_desc');
  const [wishSearch, setWishSearch] = useState('');
  const [globalSearch, setGlobalSearch] = useState('');

  // 模态框状态
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  // 表单数据
  const [createForm, setCreateForm] = useState({ name: '', description: '' });
  const [editForm, setEditForm] = useState({ name: '', description: '' });
  const [currentWish, setCurrentWish] = useState<Wish | null>(null);
  const [isBatchDelete, setIsBatchDelete] = useState(false);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '我的心愿 - 星火计划';
    return () => { document.title = originalTitle; };
  }, []);

  // 筛选和排序数据
  useEffect(() => {
    let filtered = wishesData.filter(wish => {
      const statusMatch = !statusFilter || wish.status === statusFilter;
      const searchMatch = !wishSearch || wish.name.toLowerCase().includes(wishSearch.toLowerCase());
      return statusMatch && searchMatch;
    });

    // 排序
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'created_asc':
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        case 'created_desc':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'energy_asc':
          return a.requiredEnergy - b.requiredEnergy;
        case 'energy_desc':
          return b.requiredEnergy - a.requiredEnergy;
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

    setFilteredData(filtered);
    setCurrentPage(1);
  }, [wishesData, statusFilter, sortBy, wishSearch]);

  // 计算分页信息
  const totalPages = Math.ceil(filteredData.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentPageData = filteredData.slice(startIndex, endIndex);
  const displayStart = startIndex + 1;
  const displayEnd = Math.min(endIndex, filteredData.length);

  // 全选/取消全选
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedWishes(new Set(currentPageData.map(wish => wish.id)));
    } else {
      setSelectedWishes(new Set());
    }
  };

  // 单项选择
  const handleSelectWish = (wishId: string, checked: boolean) => {
    const newSelected = new Set(selectedWishes);
    if (checked) {
      newSelected.add(wishId);
    } else {
      newSelected.delete(wishId);
    }
    setSelectedWishes(newSelected);
  };

  // 检查是否全选
  const isAllSelected = currentPageData.length > 0 && currentPageData.every(wish => selectedWishes.has(wish.id));
  const isIndeterminate = selectedWishes.size > 0 && selectedWishes.size < currentPageData.length;

  // 显示创建模态框
  const handleShowCreateModal = () => {
    setCreateForm({ name: '', description: '' });
    setShowCreateModal(true);
  };

  // 显示详情模态框
  const handleShowDetailModal = (wish: Wish) => {
    setCurrentWish(wish);
    setShowDetailModal(true);
  };

  // 显示编辑模态框
  const handleShowEditModal = (wish: Wish) => {
    setCurrentWish(wish);
    setEditForm({ name: wish.name, description: wish.description });
    setShowEditModal(true);
  };

  // 显示申请模态框
  const handleShowApplyModal = (wish: Wish) => {
    setCurrentWish(wish);
    setShowApplyModal(true);
  };

  // 显示删除模态框
  const handleShowDeleteModal = (wish: Wish, batch: boolean = false) => {
    setCurrentWish(wish);
    setIsBatchDelete(batch);
    setShowDeleteModal(true);
  };

  // 隐藏所有模态框
  const hideAllModals = () => {
    setShowCreateModal(false);
    setShowDetailModal(false);
    setShowEditModal(false);
    setShowApplyModal(false);
    setShowDeleteModal(false);
    setCurrentWish(null);
    setIsBatchDelete(false);
  };

  // 创建心愿
  const handleCreateWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.name.trim()) {
      alert('请输入心愿名称');
      return;
    }

    const newWish: Wish = {
      id: 'wish' + Date.now(),
      name: createForm.name,
      description: createForm.description,
      requiredEnergy: 0,
      currentEnergy: 1240,
      status: 'pending',
      statusText: '待审核',
      createdAt: new Date().toISOString().split('T')[0],
      canApply: false
    };

    setWishesData(prev => [newWish, ...prev]);
    hideAllModals();
    alert('心愿创建成功，等待家长审核');
  };

  // 编辑心愿
  const handleEditWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.name.trim() || !currentWish) {
      alert('请输入心愿名称');
      return;
    }

    setWishesData(prev => prev.map(wish => 
      wish.id === currentWish.id 
        ? { ...wish, name: editForm.name, description: editForm.description }
        : wish
    ));

    hideAllModals();
    alert('心愿修改成功');
  };

  // 申请实现心愿
  const handleApplyWish = () => {
    if (!currentWish) return;

    if (currentWish.currentEnergy < currentWish.requiredEnergy) {
      alert('能量值不足，无法实现此心愿');
      return;
    }

    setWishesData(prev => prev.map(wish => 
      wish.id === currentWish.id 
        ? { 
            ...wish, 
            currentEnergy: wish.currentEnergy - wish.requiredEnergy,
            status: 'achieved',
            statusText: '已实现',
            canApply: false
          }
        : wish
    ));

    hideAllModals();
    alert('心愿申请已提交，等待家长确认');
  };

  // 删除心愿
  const handleDeleteWish = () => {
    if (isBatchDelete) {
      setWishesData(prev => prev.filter(wish => !selectedWishes.has(wish.id)));
      setSelectedWishes(new Set());
    } else if (currentWish) {
      setWishesData(prev => prev.filter(wish => wish.id !== currentWish.id));
    }

    hideAllModals();
    alert('心愿删除成功');
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  };

  // 渲染分页按钮
  const renderPaginationButtons = () => {
    const buttons = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
        buttons.push(
          <button
            key={i}
            onClick={() => setCurrentPage(i)}
            className={`px-3 py-1 border rounded text-sm ${
              i === currentPage 
                ? 'border-primary bg-primary text-white' 
                : 'border-gray-300 hover:border-primary hover:text-primary'
            }`}
          >
            {i}
          </button>
        );
      } else if (i === currentPage - 2 || i === currentPage + 2) {
        buttons.push(
          <span key={`ellipsis-${i}`} className="px-2 text-gray-400">
            ...
          </span>
        );
      }
    }
    return buttons;
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50 h-16">
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo和产品名称 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-main-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-star text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>星火计划</h1>
          </div>
          
          {/* 全局搜索框 */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索任务、心愿..." 
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {/* 右侧操作区 */}
          <div className="flex items-center space-x-4">
            {/* 消息通知 */}
            <button className="relative p-2 text-gray-600 hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger text-white text-xs rounded-full flex items-center justify-center">2</span>
            </button>
            
            {/* 用户头像 */}
            <div className="relative">
              <button className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 hover:border-primary transition-colors">
                <img 
                  src="https://s.coze.cn/image/m7gdB20EvGA/" 
                  alt="用户头像" 
                  className="w-full h-full object-cover"
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className="fixed left-0 top-16 bottom-0 w-60 bg-sidebar-gradient shadow-lg overflow-y-auto">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/parent-dashboard" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tachometer-alt w-5"></i>
                  <span>仪表盘</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/task-list" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-tasks w-5"></i>
                  <span>任务</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/wish-list" 
                  className={`${styles.sidebarItem} ${styles.sidebarItemActive} flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all`}
                >
                  <i className="fas fa-heart w-5"></i>
                  <span>心愿</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-honor-wall" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-trophy w-5"></i>
                  <span>家庭荣誉墙</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/growth-report" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-chart-line w-5"></i>
                  <span>成长报告</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/knowledge-base" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-book w-5"></i>
                  <span>知识库</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/family-manage" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-users w-5"></i>
                  <span>家庭管理</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/user-profile" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-user w-5"></i>
                  <span>个人资料</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/settings" 
                  className={`${styles.sidebarItem} flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-700 transition-all`}
                >
                  <i className="fas fa-cog w-5"></i>
                  <span>设置</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 ml-60 p-6">
          {/* 页面头部 */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-text-primary mb-2">我的心愿</h2>
                <nav className="text-sm text-text-secondary">
                  <span>心愿</span>
                </nav>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={handleShowCreateModal}
                  className={`${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-plus mr-2"></i>创建心愿
                </button>
                <button 
                  onClick={() => handleShowDeleteModal(null, true)}
                  disabled={selectedWishes.size === 0}
                  className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:border-danger hover:text-danger transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-trash mr-2"></i>批量删除
                </button>
              </div>
            </div>
          </div>

          {/* 工具栏区域 */}
          <div className="bg-white rounded-2xl shadow-card p-4 mb-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center space-x-4">
                {/* 状态筛选 */}
                <div className="flex items-center space-x-2">
                  <label htmlFor="status-filter" className="text-sm font-medium text-text-secondary">状态：</label>
                  <select 
                    id="status-filter"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="">全部状态</option>
                    <option value="pending">待审核</option>
                    <option value="approved">待实现</option>
                    <option value="achieved">已实现</option>
                    <option value="rejected">已拒绝</option>
                  </select>
                </div>
                
                {/* 排序选项 */}
                <div className="flex items-center space-x-2">
                  <label htmlFor="sort-select" className="text-sm font-medium text-text-secondary">排序：</label>
                  <select 
                    id="sort-select"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="created_desc">按创建时间（最新）</option>
                    <option value="created_asc">按创建时间（最早）</option>
                    <option value="energy_desc">按所需能量（最高）</option>
                    <option value="energy_asc">按所需能量（最低）</option>
                  </select>
                </div>
              </div>
              
              {/* 搜索框 */}
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="搜索心愿名称..." 
                  value={wishSearch}
                  onChange={(e) => setWishSearch(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
            </div>
          </div>

          {/* 数据展示区域 */}
          <div className="bg-white rounded-2xl shadow-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left py-4 px-6">
                      <input 
                        type="checkbox" 
                        checked={isAllSelected}
                        ref={(input) => {
                          if (input) input.indeterminate = isIndeterminate;
                        }}
                        onChange={(e) => handleSelectAll(e.target.checked)}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                    </th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">心愿名称</th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">所需能量</th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">当前能量</th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">状态</th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">创建时间</th>
                    <th className="text-left py-4 px-6 text-sm font-semibold text-text-primary">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {currentPageData.map(wish => (
                    <tr key={wish.id} className={`${styles.tableRow} border-b border-gray-100`}>
                      <td className="py-4 px-6">
                        <input 
                          type="checkbox" 
                          value={wish.id}
                          checked={selectedWishes.has(wish.id)}
                          onChange={(e) => handleSelectWish(wish.id, e.target.checked)}
                          className="rounded border-gray-300 text-primary focus:ring-primary"
                        />
                      </td>
                      <td className="py-4 px-6">
                        <button 
                          onClick={() => handleShowDetailModal(wish)}
                          className="text-primary hover:underline font-medium"
                        >
                          {wish.name}
                        </button>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-lg font-semibold text-text-primary">{wish.requiredEnergy}</span>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full" 
                              style={{ width: `${Math.min((wish.currentEnergy / wish.requiredEnergy) * 100, 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-text-secondary">{wish.currentEnergy}/{wish.requiredEnergy}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${styles[`status${wish.status.charAt(0).toUpperCase() + wish.status.slice(1)}`]}`}>
                          {wish.statusText}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-sm text-text-secondary">
                        {formatDate(wish.createdAt)}
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex space-x-2">
                          {(wish.status === 'pending' || wish.status === 'approved') && (
                            <button 
                              onClick={() => handleShowEditModal(wish)}
                              className="text-primary text-sm hover:underline"
                            >
                              <i className="fas fa-edit mr-1"></i>编辑
                            </button>
                          )}
                          {wish.canApply && (
                            <button 
                              onClick={() => handleShowApplyModal(wish)}
                              className="text-success text-sm hover:underline"
                            >
                              <i className="fas fa-star mr-1"></i>申请实现
                            </button>
                          )}
                          <button 
                            onClick={() => handleShowDeleteModal(wish)}
                            className="text-danger text-sm hover:underline"
                          >
                            <i className="fas fa-trash mr-1"></i>删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* 分页区域 */}
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
              <div className="text-sm text-text-secondary">
                显示 <span>{displayStart}</span> - <span>{displayEnd}</span> 条，共 <span>{filteredData.length}</span> 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-gray-300 rounded text-sm hover:border-primary hover:text-primary transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <div className="flex space-x-1">
                  {renderPaginationButtons()}
                </div>
                <button 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1 border border-gray-300 rounded text-sm hover:border-primary hover:text-primary transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 创建心愿模态框 */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={hideAllModals}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} bg-white rounded-2xl shadow-xl w-full max-w-md absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-text-primary">创建心愿</h3>
                  <button onClick={hideAllModals} className="text-gray-400 hover:text-gray-600">
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <form onSubmit={handleCreateWish} className="space-y-4">
                  <div>
                    <label htmlFor="wish-name" className="block text-sm font-medium text-text-primary mb-2">心愿名称 *</label>
                    <input 
                      type="text" 
                      id="wish-name" 
                      value={createForm.name}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                      placeholder="请输入心愿名称" 
                      required 
                    />
                  </div>
                  <div>
                    <label htmlFor="wish-description" className="block text-sm font-medium text-text-primary mb-2">心愿描述</label>
                    <textarea 
                      id="wish-description" 
                      rows={3}
                      value={createForm.description}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                      placeholder="请描述你的心愿..."
                    ></textarea>
                  </div>
                  <div className="flex space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={hideAllModals}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-gray-400 transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                    >
                      提交心愿
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 心愿详情模态框 */}
      {showDetailModal && currentWish && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={hideAllModals}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} bg-white rounded-2xl shadow-xl w-full max-w-md absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-text-primary">心愿详情</h3>
                  <button onClick={hideAllModals} className="text-gray-400 hover:text-gray-600">
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">心愿名称</h4>
                    <p className="text-text-primary">{currentWish.name}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">心愿描述</h4>
                    <p className="text-text-primary">{currentWish.description || '无描述'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">所需能量</h4>
                    <p className="text-text-primary font-semibold">{currentWish.requiredEnergy} 能量值</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">当前能量</h4>
                    <p className="text-text-primary">{currentWish.currentEnergy} 能量值</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">状态</h4>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${styles[`status${currentWish.status.charAt(0).toUpperCase() + currentWish.status.slice(1)}`]}`}>
                      {currentWish.statusText}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-text-secondary mb-1">创建时间</h4>
                    <p className="text-text-primary">{formatDate(currentWish.createdAt)}</p>
                  </div>
                </div>
                <div className="flex space-x-3 pt-4">
                  <button 
                    onClick={hideAllModals}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-gray-400 transition-colors"
                  >
                    关闭
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 编辑心愿模态框 */}
      {showEditModal && currentWish && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={hideAllModals}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} bg-white rounded-2xl shadow-xl w-full max-w-md absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-text-primary">编辑心愿</h3>
                  <button onClick={hideAllModals} className="text-gray-400 hover:text-gray-600">
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <form onSubmit={handleEditWish} className="space-y-4">
                  <div>
                    <label htmlFor="edit-wish-name" className="block text-sm font-medium text-text-primary mb-2">心愿名称 *</label>
                    <input 
                      type="text" 
                      id="edit-wish-name" 
                      value={editForm.name}
                      onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                      placeholder="请输入心愿名称" 
                      required 
                    />
                  </div>
                  <div>
                    <label htmlFor="edit-wish-description" className="block text-sm font-medium text-text-primary mb-2">心愿描述</label>
                    <textarea 
                      id="edit-wish-description" 
                      rows={3}
                      value={editForm.description}
                      onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                      placeholder="请描述你的心愿..."
                    ></textarea>
                  </div>
                  <div className="flex space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={hideAllModals}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-gray-400 transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                    >
                      保存修改
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 申请实现心愿确认对话框 */}
      {showApplyModal && currentWish && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={hideAllModals}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} bg-white rounded-2xl shadow-xl w-full max-w-md absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`}>
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-star text-yellow-500 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-text-primary mb-2">申请实现心愿</h3>
                  <p className="text-sm text-text-secondary">
                    确定要申请实现心愿"<span className="font-semibold">{currentWish.name}</span>"吗？
                  </p>
                  <p className="text-sm text-text-secondary mt-2">
                    实现此心愿将消耗 <span className="font-semibold text-primary">{currentWish.requiredEnergy}</span> 能量值
                  </p>
                </div>
                <div className="flex space-x-3">
                  <button 
                    onClick={hideAllModals}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-gray-400 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleApplyWish}
                    className={`flex-1 ${styles.btnGradient} text-white px-4 py-2 rounded-lg text-sm font-medium`}
                  >
                    确认申请
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 删除确认对话框 */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={hideAllModals}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} bg-white rounded-2xl shadow-xl w-full max-w-md absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2`}>
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-text-primary mb-2">确认删除</h3>
                  <p className="text-sm text-text-secondary">
                    {isBatchDelete 
                      ? `确定要删除选中的 ${selectedWishes.size} 个心愿吗？此操作不可撤销。`
                      : `确定要删除心愿"<span className="font-semibold">${currentWish?.name}</span>"吗？此操作不可撤销。`
                    }
                  </p>
                </div>
                <div className="flex space-x-3">
                  <button 
                    onClick={hideAllModals}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:border-gray-400 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleDeleteWish}
                    className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-600 transition-colors"
                  >
                    确认删除
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WishListPage;

